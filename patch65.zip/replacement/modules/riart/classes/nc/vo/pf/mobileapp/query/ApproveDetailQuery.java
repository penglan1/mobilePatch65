package nc.vo.pf.mobileapp.query;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import nc.bs.framework.common.NCLocator;
import nc.itf.uap.IUAPQueryBS;
import nc.itf.uap.pf.IPFMobileAppService;
import nc.jdbc.framework.SQLParameter;
import nc.jdbc.framework.processor.ArrayProcessor;
import nc.jdbc.framework.processor.BeanListProcessor;
import nc.vo.jcom.lang.StringUtil;
import nc.vo.ml.MultiLangUtil;
import nc.vo.pf.mobileapp.ITaskType;
import nc.vo.pf.mobileapp.MobileAppUtil;
import nc.vo.pf.mobileapp.TaskMetaData;
import nc.vo.pub.BusinessException;
import nc.vo.pub.lang.UFDateTime;
import nc.vo.pub.workflownote.WorkflownoteVO;
import nc.vo.trade.sqlutil.IInSqlBatchCallBack;
import nc.vo.trade.sqlutil.InSqlBatchCaller;
import nc.vo.wfengine.pub.WFTask;
import nc.vo.wfengine.pub.WfTaskOrInstanceStatus;


/**
 * ������ʷ��ѯ
 * @author yanke1
 *
 */
public class ApproveDetailQuery implements IPaginationQuery<Map<String, Object>> {
	
	private final static String BILLTYPE = "#billtype#";
	private final static String BILLID = "#billid#";
	
	/**
	 * ��pub_workflownote���в�
	 * �������ѷ���������
	 * ���ݷ���ʱ����������
	 */
	
	// Aug 27th, 2018 -- PENGL
	// �޸������� senddate, dealdate�����ֶΣ���ֹ�ƶ��˱�sql��ѯ����
	private final String SQL = "select pk_checkflow, senddate, dealdate from pub_workflownote where" 
		+ " pk_billtype='" + BILLTYPE + "'" 
		+ " and billversionpk='" + BILLID + "'"
		
		// ֻȡ����ɵģ�����ʾδ�����ġ��ѷ�����
		+ " and approvestatus in (" + WfTaskOrInstanceStatus.Finished.getIntValue()+","+WfTaskOrInstanceStatus.Started.getIntValue()
		+ ") and actiontype like '" + WorkflownoteVO.WORKITEM_TYPE_APPROVE + "%'"
		
		// ���շ������ڡ�����������������
		+ " order by senddate, dealdate asc"; //�����Ҫ��������ڲ�ѯ����д���
	
	private TaskMetaData tmd = null;
	
	public ApproveDetailQuery(TaskMetaData tmd) {
		this.tmd = tmd;
	}

	@Override
	public String getIdentifier() {
		return tmd.getBillType() + tmd.getBillId();
	}

	@Override
	public String getPksSql() {
		return SQL.replace(BILLTYPE, tmd.getBillType()).replace(BILLID, tmd.getBillId());
	}

	@Override
	public List<Map<String, Object>> queryByPks(String[] pks) throws BusinessException {
		final IUAPQueryBS qry = NCLocator.getInstance().lookup(IUAPQueryBS.class);
		
		//�Ȳ���Ƶ���
		StringBuffer sb = new StringBuffer();
		String suffix = MultiLangUtil.getCurrentLangSeqSuffix();
		sb.append("select ");
		sb.append("u_t.user_name, ");
		sb.append("u_t.user_name");
		sb.append(suffix);
		sb.append(", ");
		sb.append("i_t.billmaker, i_t.startts,i_t.procstatus from pub_wf_instance i_t left join sm_user u_t on i_t.billmaker=u_t.cuserid  where i_t.billtype=? and i_t.billversionpk=? and i_t.workflow_type=?");
		SQLParameter param = new SQLParameter();
		param.addParam(tmd.getBillType());
		param.addParam(tmd.getBillId());
		// �Ƿ��ǹ������������̣�
		param.addParam(tmd.getWorkflow_type());
		Object[] summaries = (Object[]) qry.executeQuery(sb.toString(), param, new ArrayProcessor());
		
		final Map<String, WorkflownoteVO> pkVOMap = new HashMap<String, WorkflownoteVO>();

		try {
			InSqlBatchCaller caller = new InSqlBatchCaller(pks);
			caller.execute(new IInSqlBatchCallBack() {

				@Override
				public Object doWithInSql(String inSql) throws BusinessException, SQLException {
					
					String suffix = MultiLangUtil.getCurrentLangSeqSuffix();
					
					StringBuffer sb = new StringBuffer();
					
					// ����һ�������˵����ƶ���
					sb.append("select ");
					sb.append("u_t.user_name");
					sb.append(suffix);
					sb.append(" as checknameml, ");
					sb.append(" u_t.user_name as checkname, w_t.* from pub_workflownote w_t left join sm_user u_t on w_t.checkman=u_t.cuserid");
					sb.append(" where w_t.pk_checkflow in ");
					sb.append(inSql);
					Collection<WorkflownoteVO> col = (Collection<WorkflownoteVO>) qry.executeQuery(sb.toString(), new BeanListProcessor(WorkflownoteVO.class));

					if (col != null && col.size() > 0) {
						for (WorkflownoteVO vo : col) {
							pkVOMap.put(vo.getPk_checkflow(), vo);
						}

					}
					return null;
				}
			});
		} catch (SQLException e) {
			throw new BusinessException(e);
		}
		//������ʷ����Ϣ����
		List<Map<String, Object>> approveHistoryList = MobileAppUtil.createArrayList();
		//������ʷ���̽ṹ
		List<Map<String, Object>> historyUnitList = MobileAppUtil.createArrayList();
		if(pks.length>0){
			if (summaries != null) {
				//������ʷ�ύ�������̽ṹMap
				Map<String, Object> submitHistoryUnitMap = MobileAppUtil.createHashMap();
				//�ֽ��ύ������Ϣ����������ʷ���̽ṹMap��
				String billmakerName = summaries[0] == null ? null : String.valueOf(summaries[0]);
				String billmakerNameMl = summaries[1] == null ? null : String.valueOf(summaries[1]);
				String billmaker = summaries[2] == null ? null : String.valueOf(summaries[2]);
				String startts = summaries[3] == null ? null : String.valueOf(summaries[3]);
				int procstatus = summaries[4] == null ? 0 : Integer.parseInt(String.valueOf(summaries[4]));
				List<Map<String,Object>> personList = new ArrayList<Map<String,Object>>();
				Map<String,Object> personMap = MobileAppUtil.createHashMap();
				if (!StringUtil.isEmptyWithTrim(billmakerNameMl)) {
					personMap.put("name", billmakerNameMl);
				} else {
					personMap.put("name", billmakerName);
				}
				personMap.put("id", billmaker);
				List<String> activeList = new ArrayList<String>();
				activeList.add("contact");
				personMap.put("isPerson", activeList);
				personList.add(personMap);
				submitHistoryUnitMap.put("unittype", "submit");
				submitHistoryUnitMap.put("personlist", personList);
				submitHistoryUnitMap.put("time", startts);
				historyUnitList.add(submitHistoryUnitMap);
				//ѭ����ȡ�������ڹ�����ֱ����������ʷ����Ϣ����Map��������ʷ���̽ṹMap��
//				IPFMobileAppService srv = NCLocator.getInstance().lookup(IPFMobileAppService.class);
				ArrayList<WorkflownoteVO> list = new ArrayList<WorkflownoteVO>();
				for(String key: pkVOMap.keySet()){
					WorkflownoteVO wvo = pkVOMap.get(key);
					list.add(wvo);
				};
				Collections.sort(list, new Comparator<WorkflownoteVO>(){
					@Override
					public int compare(WorkflownoteVO o1, WorkflownoteVO o2) {
						UFDateTime time1 = o1.getDealdate();
						UFDateTime time2 = o2.getDealdate();
						
						// Aug 14th, 2018 -- PENGL
						// �޸�����ֹ����ʱ���ֿ�ָ���쳣
						if(time1 == null && time2 == null){
							return 0;
						}else if(time1 == null){
							return 1;
						}else if(time2 == null){
							return -1;
						}
						
						if(time1.after(time2)){
							return 1;
						}else if(time1 == time2){
							return 0;						
						}else{
							return -1;
						}

					}
					
				});
				for (WorkflownoteVO wvo : list) {
					//������ʷ����Ϣ����Map
					Map<String, Object> entry = MobileAppUtil.createHashMap();
					//������ʷ���̽ṹMap
					Map<String, Object> historyUnitMap = MobileAppUtil.createHashMap();
					if (wvo != null) {
						boolean isMakebill = WorkflownoteVO.WORKITEM_TYPE_MAKEBILL.equalsIgnoreCase(wvo.getActiontype());
						String action = WFTask.resolveApproveResult(isMakebill ? null
								: wvo.getApproveresult());
						entry.put("approvedid", wvo.getPk_checkflow());
						entry.put("psnid", wvo.getCheckman());
						entry.put("action", action);
						entry.put("note", wvo.getChecknote());
						String handledate = wvo.getDealdate() == null ? "" : wvo.getDealdate().toString();
						entry.put("handledate", handledate);
						entry.put("mark", null);
						
						if (!StringUtil.isEmptyWithTrim(wvo.getChecknameml())) {
							entry.put("handlername", wvo.getChecknameml());
						} else {
							entry.put("handlername", wvo.getCheckname());
						}
//						Map<String, Object> attMap = srv.getMessageAttachmentList(null, null, wvo.getPk_checkflow(), ITaskType.CATEGORY_RECEIVED, ITaskType.RECEIVED_HANDLED);
//						entry.putAll(attMap);
						if(list.size() !=pks.length-1){
							//�������һ����������
							historyUnitMap.put("unittype", "solved");
							historyUnitMap.put("actionname", action);
							historyUnitMap.put("advice", wvo.getChecknote());
							historyUnitMap.put("handwriteflag","N");//�Ƿ�����дǩ����ʾ
						}else{
							//���һ���������û��ɣ���Ϊ��ǰ������Ϊ����
							if(procstatus == WfTaskOrInstanceStatus.Finished.getIntValue()){
								//����
								historyUnitMap.put("unittype", "final");
								historyUnitMap.put("actionname", action);
								historyUnitMap.put("advice", wvo.getChecknote());
								historyUnitMap.put("handwriteflag","N");//�Ƿ�����дǩ����ʾ
							}else{
								//��ǰ
								historyUnitMap.put("unittype", "handling");
							}
						}
						List<Map<String,Object>> personInfos = new ArrayList<Map<String,Object>>();
						Map<String,Object> personInfo = MobileAppUtil.createHashMap();
						if (!StringUtil.isEmptyWithTrim(wvo.getChecknameml())) {
							personInfo.put("name", wvo.getChecknameml());
						} else {
							personInfo.put("name", wvo.getCheckname());
						}
						personInfo.put("id", billmaker);
						List<String> actives = new ArrayList<String>();
						actives.add("contact");
						personInfo.put("isPerson", actives);
						personInfos.add(personInfo);
						historyUnitMap.put("personlist", personInfos);
						historyUnitMap.put("mark", null);
						historyUnitMap.put("remindflag","N");//�Ƿ��д߰��ʾ
						List<Map<String,Object>> itemlist = new ArrayList<Map<String,Object>>();
						Map<String,Object> itemMap = MobileAppUtil.createHashMap();
						itemMap.put("key", "key");
						itemMap.put("value", "value");
						itemlist.add(itemMap);
						historyUnitMap.put("itemlist", itemlist);
					}
					approveHistoryList.add(entry);
					historyUnitList.add(historyUnitMap);
				}
			}
		}
		List<Map<String, Object>> resultList = MobileAppUtil.createArrayList();
		Map<String, Object> resultMap = MobileAppUtil.createHashMap();
		resultMap.put("approvehistorylinelist", approveHistoryList);
		resultMap.put("flowhistory", historyUnitList);
		resultList.add(resultMap);
		return resultList;
	}

}
