package nc.vo.pf.mobileapp;

import java.io.ByteArrayOutputStream;
import java.io.CharArrayWriter;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import nc.bs.framework.common.InvocationInfoProxy;
import nc.bs.framework.common.NCLocator;
import nc.bs.logging.Logger;
import nc.bs.mapp.conf.MappConfAccessor;
import nc.bs.ml.NCLangResOnserver;
import nc.bs.pf.pub.PFRequestDataCacheProxy;
import nc.bs.pf.pub.PfDataCache;
import nc.bs.pf.pub.WorkflowProcessCache;
import nc.bs.pf.pub.cache.CondStringKey;
import nc.bs.pf.pub.cache.ICacheDataQueryCallback;
import nc.bs.pf.pub.cache.IRequestDataCacheKey;
import nc.itf.uap.IUAPQueryBS;
import nc.itf.uap.billtemplate.IBillTemplateQry;
import nc.itf.uap.pf.IPFConfig;
import nc.itf.uap.pf.IPFTemplate;
import nc.itf.uap.pf.IWorkflowDefine;
import nc.itf.uap.pf.IWorkflowMachine;
import nc.itf.uap.print.IPrintEntry;
import nc.jdbc.framework.SQLParameter;
import nc.jdbc.framework.processor.ColumnProcessor;
import nc.ui.pf.multilang.PfMultiLangUtil;
import nc.ui.pub.print.IDataSource;
import nc.vo.bd.psn.PsnjobVO;
import nc.vo.jcom.lang.StringUtil;
import nc.vo.ml.MultiLangUtil;
import nc.vo.org.DeptVO;
import nc.vo.org.JobVO;
import nc.vo.pf.mobileapp.query.BillVORowCountKey;
import nc.vo.pf.mobileapp.query.TaskQuery;
import nc.vo.pf.pub.util.ArrayUtil;
import nc.vo.pub.AggregatedValueObject;
import nc.vo.pub.BusinessException;
import nc.vo.pub.BusinessRuntimeException;
import nc.vo.pub.bill.BillTempletVO;
import nc.vo.pub.billtype.BilltypeVO;
import nc.vo.pub.lang.UFDouble;
import nc.vo.pub.pf.AssignableInfo;
import nc.vo.pub.pf.PFClientBizRetVO;
import nc.vo.pub.template.ITemplateStyle;
import nc.vo.pub.workflownote.WorkflownoteVO;
import nc.vo.uap.pf.TemplateParaVO;
import nc.vo.wfengine.core.parser.XPDLNames;
import nc.vo.wfengine.core.workflow.BasicWorkflowProcess;
import nc.vo.wfengine.pub.WFTask;
import nc.vo.wfengine.pub.WfTaskOrInstanceStatus;

/**
 * ����ƽ̨�ƶ�Ӧ�ù�����
 * @author yanke1
 *
 */
public class MobileAppUtil {
	
	public static final Integer TRIM_TO_COUNT = 300;
	
	/**
	 * ����һ��ArrayList
	 * @return
	 */
	public static ArrayList<Map<String, Object>> createArrayList() {
		return new ArrayList<Map<String, Object>>();
	}
	
	/**
	 * ����һ��HashMap
	 * @return
	 */
	public static HashMap<String, Object> createHashMap() {
		return new HashMap<String, Object>();
	}
	
	public static LinkedHashMap<String, Object> createLinkedHashMap() {
		return new LinkedHashMap<String, Object>();
	}
	
	public static Map<Object, Map<String, Object>> convertToMap(List<Map<String, Object>> list, String key) {
		Map<Object, Map<String, Object>> resultMap = new HashMap<Object, Map<String,Object>>();
		
		
		for (Map<String, Object> map : list) {
			resultMap.put(map.get(key), map);
		}
	
		return resultMap;
	}
	
	  /**
	   * ��UFDoubleȡ��λ���ȣ�������λ����
	   * 
	   * @example
	   *          -3.14150000->-3.1415<br>
	   *          -3.14000000->-3.14<br>
	   *          -3.10000000->-3.10<br>
	   *          300.00000000->300.00<br>
	   *          1.00000000->1.00<br>
	   *          0.00000000->0.00<br>
	   * @author zhaoyha ��л���֣���
	   */
	public static UFDouble adjust2Scale(UFDouble value) {
		value.setTrimZero(true);
		String struf = value.toString();
		if (struf.lastIndexOf(".") > 0 && struf.length() - (struf.lastIndexOf(".") + 1) >= 2) {
			return value;
		}
		value.setTrimZero(false);
		return value.setScale(0 - 2, UFDouble.ROUND_HALF_UP);
	}

	
	/**
	 * ��������������������ȡ��������ʵ��
	 * @param category
	 * @param code
	 * @return
	 */
	public static ITaskType getTaskType(String category, String code) {
		ITaskType taskType = TaskTypeFactory.getInstance().get(category, code);

		if (taskType == null) {
			throw new IllegalArgumentException("invalid category or code: " + category + ", " + code);
		}
		
		return taskType;
	}
	
	/**
	 * ��Object���飨ͨ����Դ��jdbcframework��ArrayListProcessor����ȡ�ַ���
	 * @param objs
	 * @param idx
	 * @return
	 */
	public static String getStringFromObjects(Object[] objs, int idx) {
		if (objs == null) {
			return null;
		}
		
		if (idx >= objs.length) {
			return null;
		}
		
		return objs[idx] == null ? null : String.valueOf(objs[idx]);
	}
	
	
	/**
	 * ����������𡢱��롢����id��ѯ����ʵ��
	 * @param category
	 * @param code
	 * @param taskid
	 * @return
	 * @throws BusinessException
	 */
	public static TaskMetaData queryTaskMetaData(final String category, final String code, final String taskid) throws BusinessException {
		IRequestDataCacheKey key = new CondStringKey(IRequestDataCacheKey.CATEGORY_MA_QUERY_TASK_METADATA,
				new String[] {
					category,
					code,
					taskid
		});	
		ICacheDataQueryCallback<TaskMetaData> callback = new ICacheDataQueryCallback<TaskMetaData>() {

			@Override
			public TaskMetaData queryData() throws BusinessException {
				ITaskType taskType = getTaskType(category, code);
				TaskQuery query = taskType.createNewTaskQuery();

				TaskMetaData tmd = query.queryTaskMetaData(taskid);
				return tmd;
			}
		};
		
		return PFRequestDataCacheProxy.get(key, callback);
	}
	
	/**
	 * ��ȡһ��������pk��Ӧ��WorkflownoteVOʵ�壬���г��˰��������������Ϣ
	 * �������˹������ϵ�һЩ��Ϣ������ָ����Ϣ��
	 * @param pk_checkflow
	 * @return
	 * @throws BusinessException
	 */
	public static WorkflownoteVO checkWorkflow(String pk_checkflow) throws BusinessException {
		TaskMetaData tmd = MobileAppUtil.queryTaskMetaData(ITaskType.CATEGORY_RECEIVED, ITaskType.RECEIVED_UNHANDLED, pk_checkflow);
		return checkWorkflow(tmd);
	}
	
	/**
	 * ��ȡһ��������pk��Ӧ��WorkflownoteVOʵ�壬���г��˰��������������Ϣ
	 * �������˹������ϵ�һЩ��Ϣ������ָ����Ϣ��
	 * @param tmd
	 * @param billvo
	 * @return
	 * @throws BusinessException
	 */
	public static WorkflownoteVO checkWorkflow(TaskMetaData tmd) throws BusinessException {
		IWorkflowMachine srv = NCLocator.getInstance().lookup(IWorkflowMachine.class);
		WorkflownoteVO note = srv.checkWorkflowActions(tmd.getBillType(), tmd.getBillId());
	
		return note;
	}
	
	public static PFClientBizRetVO executeClientBiz(AggregatedValueObject aggvo, WorkflownoteVO wfvo) throws BusinessException {
		IWorkflowMachine srv = NCLocator.getInstance().lookup(IWorkflowMachine.class);
		return srv.executeClientBizProcess(aggvo, wfvo, false);
	}
	
	/**
	 * ��ѯ�ƶ�Ӧ��ģ��id
	 * @param tmd
	 * @return
	 * @throws BusinessException
	 */
	public static String queryTemplateId(TaskMetaData tmd) throws BusinessException {
		String billtype = tmd.getBillType();
		String cuserid = tmd.getCuserid();
		String pk_group = InvocationInfoProxy.getInstance().getGroupId();

		BilltypeVO btvo = PfDataCache.getBillTypeInfo(billtype);

		String funnode = btvo.getNodecode();

		TemplateParaVO para = new TemplateParaVO();

		para.setFunNode(funnode);
		para.setOperator(cuserid);
		para.setPk_Corp(pk_group);
		para.setTemplateType(ITemplateStyle.mobileAppTemplate);
		
		IPFTemplate srv = NCLocator.getInstance().lookup(IPFTemplate.class);
		String templateid = srv.getTemplateId(para);
	
		return templateid;
	}
	
	/**
	 * ��ѯ�ƶ�Ӧ��ģ��ʵ��
	 * @param pk_template
	 * @return
	 * @throws BusinessException
	 */
	public static BillTempletVO queryTemplate(String pk_template) throws BusinessException {
		IBillTemplateQry qry = (IBillTemplateQry) NCLocator.getInstance()
				.lookup(IBillTemplateQry.class.getName());
		BillTempletVO vo = qry.findTempletData(pk_template);
		
		return vo;
	}
	
	/**
	 * ��ѯ���ݾۺ�vo
	 * @param billtype
	 * @param billid
	 * @return
	 * @throws BusinessException
	 */
	public static AggregatedValueObject queryBillEntity(final String billtype, final String billid) throws BusinessException {
		IRequestDataCacheKey key = new CondStringKey(IRequestDataCacheKey.CATEGORY_MA_QUERY_BILLENTITY,
				new String[] {
					billtype,
					billid
		});
		ICacheDataQueryCallback<AggregatedValueObject> callback = new ICacheDataQueryCallback<AggregatedValueObject>() {

			@Override
			public AggregatedValueObject queryData() throws BusinessException {
				AggregatedValueObject busiObj = NCLocator.getInstance().lookup(IPFConfig.class).queryBillDataVO(billtype, billid);
				return busiObj;
			}
		};
		
		return PFRequestDataCacheProxy.get(key, callback);
	}
	
	/**
	 * @param note ����IWorkflowMachine.checkWorkflow()
	 * @return
	 */
	public static boolean canAddApprover(WorkflownoteVO note) {
		Object value = note.getRelaProperties().get(
				XPDLNames.CAN_ADDAPPROVER);
		if (value != null && "true".equalsIgnoreCase(value.toString())) {
			if (note.actiontype.endsWith(WorkflownoteVO.WORKITEM_ADDAPPROVER_SUFFIX))
				return false;
			else
				return true;
		} else
			return false;
	}
	
	
	
	/**
	 * @param note ����IWorkflowMachine.checkWorkflow()
	 * @return
	 */
	public static boolean canReject(PFClientBizRetVO bizret, WorkflownoteVO note) {
		if (bizret != null && !bizret.isShowReject()) {
			return false;
		}
		// ��ǩ���û�����������
		return !note.getActiontype().endsWith(WorkflownoteVO.WORKITEM_ADDAPPROVER_SUFFIX);
	}
	
	public static boolean canAgree(PFClientBizRetVO bizret, WorkflownoteVO note) {
		if (bizret != null && !bizret.isShowPass()) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * @param note ����IWorkflowMachine.checkWorkflow()
	 * @return
	 */
	public static boolean canDisAgree(PFClientBizRetVO bizret, WorkflownoteVO note) {
		if (bizret != null && !bizret.isShowNoPass()) {
			return false;
		}
		
		try {
			String pk_wf_def = getPk_wf_def(note);
			BasicWorkflowProcess process = WorkflowProcessCache.getInstance().getWorkflowProcess(pk_wf_def);
			
			if (process != null) {
				return !process.isHideNoPassing();
			} else {
				return false;
			}
		} catch (BusinessException e) {
			throw new BusinessRuntimeException(e.getMessage(), e);
		}
	}
	
	@SuppressWarnings("unchecked")
	private static String getPk_wf_def(WorkflownoteVO note) throws BusinessException {
		if (note.getTaskInfo() != null
				&& note.getTaskInfo().getTask() != null) {
			return note.getTaskInfo().getTask().getWfProcessDefPK();
		} else {
			String cond = "pk_wf_task=?";
			SQLParameter param = new SQLParameter();
			param.addParam(note.getPk_wf_task());
			
			IUAPQueryBS qry = NCLocator.getInstance().lookup(IUAPQueryBS.class);
			Collection<WFTask> taskCol = qry.retrieveByClause(
					WFTask.class, 
					WFTask.mappingMeta,
					cond, 
					new String[] {
						"pk_wf_task",
						"processdefid"
					},
					param
				);
			
			if (ArrayUtil.isNull(taskCol)) {
				return null;
			} else {
				return taskCol.iterator().next().getWfProcessDefPK();
			}
		}
	}
	
	/**
	 * @param note ����IWorkflowMachine.checkWorkflow()
	 * @return
	 */
	public static boolean canReassign(WorkflownoteVO note) {
		Object value = note.getRelaProperties().get(
				XPDLNames.CAN_TRANSFER);
		if (value != null && "true".equalsIgnoreCase(value.toString())) {
			if (note.actiontype.endsWith(WorkflownoteVO.WORKITEM_ADDAPPROVER_SUFFIX)) {
				return false;
			} else {
				return true;
			}
		} else {
			return false;
		}
	}
	
	/**
	 * @param note ����IWorkflowMachine.checkWorkflow()
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static boolean canAssignWhenNoPass(WorkflownoteVO note) {
		if (note.getActiontype().endsWith(
				WorkflownoteVO.WORKITEM_ADDAPPROVER_SUFFIX))
			return false;

		Vector<AssignableInfo> assignInfos = note.getTaskInfo()
				.getAssignableInfos();
		if (assignInfos != null && assignInfos.size() > 0) {
			String strCriterion = null;
			for (AssignableInfo ai : assignInfos) {
				strCriterion = ai.getCheckResultCriterion();
				if (AssignableInfo.CRITERION_NOTGIVEN.equals(strCriterion)
						|| AssignableInfo.CRITERION_NOPASS.equals(strCriterion))
					return true;
			}
		}
		return false;
	}
	
	/**
	 * @param note ����IWorkflowMachine.checkWorkflow()
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static boolean canAssignWhenPassing(WorkflownoteVO note) {
		if (note.getActiontype().endsWith(
				WorkflownoteVO.WORKITEM_ADDAPPROVER_SUFFIX))
			return false;

		Vector<AssignableInfo> assignInfos = note.getTaskInfo()
				.getAssignableInfos();
		if (assignInfos != null && assignInfos.size() > 0) {
			String strCriterion = null;
			for (AssignableInfo ai : assignInfos) {
				strCriterion = ai.getCheckResultCriterion();
				if (AssignableInfo.CRITERION_NOTGIVEN.equals(strCriterion)
						|| AssignableInfo.CRITERION_PASS.equals(strCriterion))
					return true;
			}
		}
		return false;
	}
	
	public static <T> List<T> subList(List<T> list, int startIndex, int count) {
		// List.subList�Ľ��List����serializable��
		// �����һ��ArrayList��װһ��
		List<T> resultList = new ArrayList<T>();
		
		int size = list.size();
		int endIndex = startIndex + count;
		
		if (startIndex >= size) {
			return resultList;
		}
		
		if (endIndex > size) {
			endIndex = size;
		}
		
		List<T> subList = list.subList(startIndex, endIndex);
		
		resultList.addAll(subList);
		
		return resultList;
	}
	
	public static String getStack(Throwable e) {
		CharArrayWriter cw = null;
		PrintWriter pw = null;

		try {
			cw = new CharArrayWriter();
			pw = new PrintWriter(cw);

			e.printStackTrace(pw);

			String msg = cw.toString();
			return msg;
		} catch (Exception ex) {
			Logger.error(ex.getMessage(), ex);
			return null;
		} finally {
			if (pw != null) {
				pw.close();
			}
		}
	}
	
	public static String getMaPushServlet() {
		String servlet = MappConfAccessor.getInstance().getProperty("mapurl");
		String url = "/" + servlet;
		
		return url;
	}
	
	public static String getMaHost() {
		return MappConfAccessor.getInstance().getMappHost();
	}
	
	public static int getMaPort() {
		try {
			return Integer.parseInt(MappConfAccessor.getInstance().getMappPort());
		} catch (Throwable e) {
			Logger.error(e.getMessage(), e);
			return 8090;
		}
	}
	
	public static String getMaPushServiceCode() {
		return MappConfAccessor.getInstance().getProperty("mapmessageserviceid");
	}
	
	/**
	 * ��ȡһ����Ա������ְλ��Ϣ
	 * @param pk_psndoc
	 * @return
	 * @throws BusinessException
	 */
	@SuppressWarnings("unchecked")
	public static String getPsnJobInfo(String pk_psndoc) throws BusinessException {
		IUAPQueryBS qry = NCLocator.getInstance().lookup(IUAPQueryBS.class);
		
		// Aug 27th, 2018 -- PENGL
		// �޸��� ��ȡ��Ա��������ְ��Ϣ
		String cond = "pk_psndoc=? and enddutydate is null";
		
		SQLParameter param = new SQLParameter();
		param.addParam(pk_psndoc);
		
		String[] fields = new String[] {PsnjobVO.PK_JOB, PsnjobVO.PK_DEPT};
		
		Collection<PsnjobVO> col = qry.retrieveByClause(PsnjobVO.class, cond, fields, param);
		
		StringBuffer sb = new StringBuffer();
		if (col != null && col.size() > 0) {
			PsnjobVO pjv = col.iterator().next();

			if (!StringUtil.isEmptyWithTrim(pjv.getPk_dept())) {
				cond = DeptVO.PK_DEPT + "=?";
				
				param = new SQLParameter();
				param.addParam(pjv.getPk_dept());
				
				fields = new String[] { DeptVO.NAME, DeptVO.NAME + MultiLangUtil.getCurrentLangSeqSuffix() };
				
				Collection<DeptVO> deptCol = qry.retrieveByClause(DeptVO.class, cond, fields, param);
				
				if (deptCol != null && deptCol.size() > 0) {
					DeptVO dvo = deptCol.iterator().next();
					
					String deptName = PfMultiLangUtil.getSuperVONameOfCurrentLang(dvo, DeptVO.NAME);
					sb.append(deptName);
				}
			}
			
			if (!StringUtil.isEmptyWithTrim(pjv.getPk_job())) {
				cond = JobVO.PK_JOB + "=?";
				
				param = new SQLParameter();
				param.addParam(pjv.getPk_job());
				
				fields = new String[] { JobVO.JOBNAME, JobVO.JOBNAME + MultiLangUtil.getCurrentLangSeqSuffix() };
				
				Collection<JobVO> jobCol = qry.retrieveByClause(JobVO.class, cond, fields, param);
				
				if (jobCol != null && jobCol.size() > 0) {
					JobVO jvo = jobCol.iterator().next();
					
					String jobName = PfMultiLangUtil.getSuperVONameOfCurrentLang(jvo, JobVO.JOBNAME);
					
					if (sb.length() > 0) {
						sb.append(", ");
					}
					sb.append(jobName);
				}
			}
		}
		
		return sb.toString();
	}
	
	/**
	 * ͬһ�߳�����Ч
	 * @param cnt
	 */
	public static void setRowCount(Integer cnt) {
		IRequestDataCacheKey key = new BillVORowCountKey();
		PFRequestDataCacheProxy.put(key, cnt);
	}
	
	/**
	 * ͬһ�߳�����Ч
	 * @return
	 */
	public static Integer getRowCount() {
		Object rowCount = PFRequestDataCacheProxy.get(new BillVORowCountKey());
		if (rowCount != null && rowCount instanceof Integer) {
			return (Integer) rowCount;
		}
		return Integer.valueOf(0);
	}
	
	
	public static void handleException(Exception e) throws BusinessException {
		if (e instanceof BusinessException) {
			throw (BusinessException) e;
		} else {
			throw new BusinessException(e.getMessage(), e);
		}
	}
	
	/**
	 * ��ѯ�û�δ��������������
	 * @return
	 */
	public static List<Map<String, String>> getWorkNumByUserIds(String groupid,List<String> usridsList,String type) throws BusinessException {
		//�ƶ����type�̶�Ϊ��task���������Ժ���չ,��ʱ������
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		Map<String,String> countMap = getWorkNumByUseridList(groupid, usridsList, type);
		for(Map.Entry<String, String> entry : countMap.entrySet()){
			Map<String,String> tempMap = new HashMap<String,String>();
			tempMap.put("usrid", entry.getKey());
			tempMap.put("badge", entry.getValue());
			list.add(tempMap);
		}
		return list;
	}
	
	/**
	 * ��ѯ�û�δ��������������
	 * @return
	 */
	public static Map<String,String> getWorkNumByUseridList(String groupid,List<String> usridList,String type) throws BusinessException {
		//�ƶ����type�̶�Ϊ��task���������Ժ���չ,��ʱ������
		String sql="select count(pk_checkflow) from pub_workflownote where actiontype like 'Z%'"
				+" and pk_group = '"+groupid+"'"
				+" and approvestatus = "+WfTaskOrInstanceStatus.Started.getIntValue()
				+" and checkman = ?";
		try {
			sql = MobileTaskFilterHandler.getFinalSqlWithWfWork(sql);
		} catch (BusinessException e) {
			Logger.error(e.getMessage(), e);
			handleException(e);
		}
		Map<String, String> resultMap = new HashMap<String, String>();
		if(usridList != null && usridList.size()>0 && groupid != null){
			IUAPQueryBS qry = NCLocator.getInstance().lookup(IUAPQueryBS.class);
			for(String checkman : usridList){
				SQLParameter param = new SQLParameter();
				param.addParam(checkman);
				String badge = qry.executeQuery(sql, param, new ColumnProcessor()).toString();
				resultMap.put(checkman, badge);
			}
		}else{
			String err = NCLangResOnserver.getInstance().getStrByID("mobileapp", "TaskNotValidException-000001")/*�޷��ҵ�����ļ���ID���û�ID*/;
			handleException(new BusinessException(err));
		}
		return resultMap;
	}
	
	/**
	 * ��ѯ�ƶ�Ӧ�ô�ӡģ����������ʾ
	 * @param billID,billType,printTempletid
	 * @return
	 * @throws BusinessException
	 */
	public static List<Map<String,Object>> getHtmlOfPrintTemplete(String billID, String billType, String printTempletid) throws BusinessException {
		List<Map<String,Object>> htmlList = new ArrayList<Map<String,Object>>();
		byte[] billHtml = null;
		if (StringUtil.isEmptyWithTrim(printTempletid))
			return null;
		IDataSource ds = (IDataSource) NCLocator.getInstance().lookup(IWorkflowDefine.class).getDataSourceForMobile(billType, billID);
		if (ds == null) {
			return null;
		}
		try {
			IPrintEntry printEntry = (IPrintEntry) NCLocator.getInstance().lookup(IPrintEntry.class.getName());
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			IDataSource[] dataSources = new IDataSource[] { ds };
			printEntry.exportHtml(dataSources, printTempletid, new OutputStreamWriter(bos, "UTF-8"));
			billHtml = bos.toByteArray();
			Map<String, Object> map = createHashMap(); 
			map.put("htmlname", billType);
			map.put("htmlfile", billHtml);
			htmlList.add(map);
			Logger.debug("�ƶ�����ȫòHTML�����ɹ�");
		} catch (Throwable e) {
			// XXX::����־�쳣�����񲻻ع�
			Logger.error(">>��̨��ӡģ�����HTML����=" + e.getMessage(), e);
			handleException(new BusinessException(e.getMessage()));
		}
		return htmlList;
	}
	
	/**
	 * ��ѯ�ƶ��Ĵ�ӡģ��id
	 * @param tmd
	 * @return
	 * @throws BusinessException
	 */
	public static String queryPrintTemplateId(TaskMetaData tmd) throws BusinessException {
		String billtype = tmd.getBillType();
		String cuserid = tmd.getCuserid();
		String pk_group = InvocationInfoProxy.getInstance().getGroupId();
		BilltypeVO btvo = PfDataCache.getBillTypeInfo(billtype);
		String funnode = btvo.getNodecode();
		TemplateParaVO para = new TemplateParaVO();
		para.setFunNode(funnode);
		para.setOperator(cuserid);
		para.setPk_Corp(pk_group);
		para.setTemplateType(ITemplateStyle.printTemplate);
		para.setNodeKey("useMobileForBill");
		IPFTemplate srv = NCLocator.getInstance().lookup(IPFTemplate.class);
		String templateid = srv.getTemplateId(para);
		return templateid;
	}
	
	public static Map<String, Object> toPNGImagesWithSubFlow(String billId, String billType,int iWorkflowtype,String pk_busiworkflow) throws BusinessException{
		
		IWorkflowDefine workflowDefine = NCLocator.getInstance().lookup(IWorkflowDefine.class);
		try {
			return workflowDefine.toPNGImagesWithMobile(billId, billType, iWorkflowtype, pk_busiworkflow);
		} catch (BusinessException e) {
			// TODO Auto-generated catch block
			Logger.error(">>�ƶ��˲�ѯ����ͼ����=" + e.getMessage(), e);
			return null;
		}
		
	}
	
}
