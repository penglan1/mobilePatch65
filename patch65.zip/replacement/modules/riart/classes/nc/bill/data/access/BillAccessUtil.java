package nc.bill.data.access;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import nc.ui.bd.ref.AbstractRefModel;
import nc.ui.pub.beans.constenum.DefaultConstEnum;
import nc.vo.pub.ISuperVO;
import nc.vo.pub.bill.BillTabVO;
import nc.vo.pub.bill.server.BillVO;
import nc.vo.pub.bill.server.IBillDataConst;
import nc.vo.pub.bill.server.IBillItemMeta;

public class BillAccessUtil {

	private static BillAccessUtil instance = null;
	private Map<String,AbstractRefModel> refMap = new HashMap<String, AbstractRefModel>();

	private BillAccessUtil() {

	}

	public synchronized static BillAccessUtil getInstance() {
		if (instance == null) {
			instance = new BillAccessUtil();
		}
		return instance;
	}
	
	// ��������
	public List<Map<String, Object>> getTabDataMap(BillVO billVO,
			BillTabVO tabVO, ISuperVO[] vos) {
		if (vos == null) {
			return null;
		}
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < vos.length; i++) {
			list.add(getTabDataMap(billVO, tabVO, vos[i]));
		}

		return list;
	}

	// ҳǩ�µ�һ����¼ ��Ϊһ��Map��Map��Ϊ IBillDataConst.BILLITEMDATA��IBillDataConst._GROUP
	// Ϊkey������
	// ÿ��BillItemΪһ��Map��map��Ϊ billItem ����ʾ���ƣ�value,����ǲ������ͻ���PKֵ��

	public Map<String, Object> getTabDataMap(BillVO billVO, BillTabVO tabVO,
			ISuperVO vo) {
		List<Map> recordList = new ArrayList<Map>();
		Map<String, Object> recordMap = new LinkedHashMap<String, Object>();
		List<IBillItemMeta> billItemList = billVO
				.getBillTItemMetasByTabCode(tabVO.getTabcode());
		for (Iterator iterator = billItemList.iterator(); iterator.hasNext();) {
			IBillItemMeta billItemMeta = (IBillItemMeta) iterator.next();
			if (!billItemMeta.isShow()){
				continue;
			}
			String key = billItemMeta.getKey();
			Object value = vo.getAttributeValue(billItemMeta.getKey());
			Map<String, Object> map = new LinkedHashMap<String, Object>();

			Object pk = null;

			switch (billItemMeta.getDataType()) {
			case IBillDataConst.COMBO:

				if (value != null) {
//					wanglio update 20150519 ö���ͱ����޷����ƶ��ն���ʾ
//					value = ((DefaultConstEnum) value).getName();
					if (value instanceof Integer){
						Object billObject = new DefaultConstEnum(value, value.toString());
						DefaultConstEnum[] enumData = ComboBoxBillItemUtil
								.getInstance().getComboxItems(billItemMeta);
						if (enumData != null) {
							for (int i = 0; i < enumData.length; i++) {
								if (value.toString().equals(
										enumData[i].getValue().toString()))
									billObject = enumData[i];
							}
						}
						value = billObject;
						
					}else{
						value = ((DefaultConstEnum) value).getName();
					}
				}

				break;

			case IBillDataConst.UFREF:
				if (value != null) {
					DefaultConstEnum refValue=null;
					if(value instanceof String){
						refValue = new DefaultConstEnum(value,(String) value);
					}else{
					  refValue = (DefaultConstEnum) value;
					  
					}
					pk = refValue.getValue();
					value = refValue.getName();
				}
				break;
			//add by fanchj1 2015/11/17���ڿ����ƶ�����ʾ����С��λ��
			case IBillDataConst.DECIMAL:
				value = value == null ? "" : value.toString();
				break;
			}
			map.put(billItemMeta.getKey() + IBillDataConst.ITEMSHOWNAME,
					billItemMeta.getCaption());
			map.put(billItemMeta.getKey(), value);
			if (pk != null) {

				map.put(billItemMeta.getKey() + IBillDataConst.ID_SUFFIX, pk);
			}
			map.put(IBillDataConst.DIGEST, billItemMeta.isRemarkItem());
			recordList.add(map);

		}
		recordMap.put(IBillDataConst.BILLITEMDATA, recordList);

		// ������ҳǩ��������

		List<BillTabVO> grpTabList = billVO.getGroupTabVOByTabCode(tabVO
				.getTabcode());

		if (grpTabList != null) {
			List<Map<String, Object>> grpList = new ArrayList<Map<String, Object>>();
			for (Iterator iterator = grpTabList.iterator(); iterator.hasNext();) {
				Map<String, Object> grpMap = new LinkedHashMap<String, Object>();
				BillTabVO billTabVO = (BillTabVO) iterator.next();
				grpMap.put(IBillDataConst.TABCODE, billTabVO.getTabcode());
				grpMap.put(IBillDataConst.TABNAME, billTabVO.getTabname());
				grpMap.put(IBillDataConst.TABCONTENT, getTabDataMap(billVO,
						billTabVO, vo));
				grpList.add(grpMap);
			}
			recordMap.put(IBillDataConst.GROUP, grpList);

		}

		return recordMap;
	}

	public void putRefMOdel(String refNodeName,AbstractRefModel model) {
		refMap.put(refNodeName, model);
	}
	public AbstractRefModel getRefModel(String refNodeName){
		return refMap.get(refNodeName);
	}
}
