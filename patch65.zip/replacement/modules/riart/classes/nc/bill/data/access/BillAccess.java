package nc.bill.data.access;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import nc.bill.data.access.formula.FormulaProc;
import nc.bill.data.access.formula.FormulaUtil;
import nc.bs.framework.common.NCLocator;
import nc.bs.logging.Logger;
import nc.itf.uap.billtemplate.IBillTemplateQry;
import nc.md.data.access.DASFacade;
import nc.md.data.access.NCObject;
import nc.md.model.IBusinessEntity;
import nc.md.model.access.javamap.BeanStyleEnum;
import nc.ui.bd.ref.AbstractRefModel;
import nc.ui.bd.ref.RefPubUtil;
import nc.ui.pub.beans.constenum.DefaultConstEnum;
import nc.ui.pub.beans.constenum.IConstEnum;
import nc.ui.pub.bill.IBillItem;
import nc.vo.pub.AggregatedValueObject;
import nc.vo.pub.BusinessException;
import nc.vo.pub.ISuperVO;
import nc.vo.pub.bill.BillTabVO;
import nc.vo.pub.bill.BillTempletVO;
import nc.vo.pub.bill.server.BillDataVO;
import nc.vo.pub.bill.server.BillItemMeta;
import nc.vo.pub.bill.server.BillVO;
import nc.vo.pub.bill.server.IBillDataConst;
import nc.vo.pub.bill.server.IBillItemMeta;
import nc.vo.pub.lang.MultiLangText;
import nc.vo.pub.lang.UFBoolean;
import nc.vo.pub.templet.translator.BillTranslator;

public class BillAccess {

	private BillTempletVO billTempletVO = null;
	private Object oData = null;
	private String pk_billTemplet = null;
    private BillVO billVO = null;

	BillAccessRefBatchMatch refBatchMatch = new BillAccessRefBatchMatch();

	public BillAccess(String pk_billTemplet, Object oData) {
		this.pk_billTemplet = pk_billTemplet;
		this.oData = oData;
		init();

	}

	public BillAccess(BillTempletVO billTempletVO, Object oData) {
		this.billTempletVO = billTempletVO;
		BillTranslator.translate(billTempletVO);
		this.oData = oData;

	}

	private void init() {
		billTempletVO = getBillTempletVO(pk_billTemplet);

	}

	private int getBodyRowAcount() {
		int rowAccount = 0;
		if (oData instanceof AggregatedValueObject) {
			AggregatedValueObject aggrVO = (AggregatedValueObject) oData;
			if (aggrVO.getChildrenVO() != null) {
				rowAccount = aggrVO.getChildrenVO().length;
			}
		}
		return rowAccount;
	}

	private BillTempletVO getBillTempletVO(String pk_billTemplet) {

		BillTempletVO vo = null;
		IBillTemplateQry qry = (IBillTemplateQry) NCLocator.getInstance()
				.lookup(IBillTemplateQry.class.getName());
		try {
			vo = qry.findTempletData(pk_billTemplet);
			BillTranslator.translate(vo);
		} catch (BusinessException e) {
			// TODO Auto-generated catch block
			Logger.error(e.getMessage(), e);
		}
		return vo;
	}

	private BillItemMeta[] getHeadTailItemMetas() {
		return (BillItemMeta[]) nc.vo.bill.pub.MiscUtil.ArraysCat(getBillVO()
				.getBillItemMeta(IBillItem.HEAD), getBillVO().getBillItemMeta(
				IBillItem.TAIL));
	}

	private BillTabVO[] getBaseBodyTabVos() {
		BillTabVO[] tabVOs = getBillTempletVO().getHeadVO().getStructvo()
				.getBillTabVOs();

		if (tabVOs == null)
			return null;

		ArrayList<BillTabVO> list = new ArrayList<BillTabVO>();
		for (int i = 0; i < tabVOs.length; i++) {
			BillTabVO vo = tabVOs[i];
			if (vo.getPos() == IBillItem.BODY && vo.getBasetab() == null)
				list.add(vo);
		}

		if (list.size() == 0)
			return null;
		BillTabVO[] vos = list.toArray(new BillTabVO[list.size()]);
		// BillUtil.sortBillTabVO(vos);

		return vos;
	}

	private void setItemValue(IBillItemMeta item, ISuperVO superVO, Object value) {

		if (value == null) {
			return;
		}

		Object billObject = value;
		if (item != null) {

			switch (item.getDataType()) {
			case IBillItem.COMBO:

				if (value != null) {
					long begin = System.currentTimeMillis();
					Logger.debug("������:" + item.getKey() + " COMBOƥ�俪ʼ");
					billObject = new DefaultConstEnum(value, value.toString());
					DefaultConstEnum[] enumData = ComboBoxBillItemUtil
							.getInstance().getComboxItems(item);
					if (enumData != null) {
						for (int i = 0; i < enumData.length; i++) {
							if (value.toString().equals(
									enumData[i].getValue().toString()))
								billObject = enumData[i];
						}
					}
					long end = System.currentTimeMillis();
					Logger.debug("������:" + item.getKey() + " COMBOƥ������������ѣ�"
							+ (end - begin) + "Ms");
				}

				break;

			case IBillItem.UFREF:
				if (item.getMetaDataProperty() == null
						&& item.getRefType() != null) {

					// long begin = System.currentTimeMillis();

					String refNodeName = item.getRefType().split(",")[0];

					AbstractRefModel model = BillAccessUtil.getInstance()
							.getRefModel(refNodeName);
					if (model == null) {

						model = RefPubUtil.getRefModel(refNodeName);
						BillAccessUtil.getInstance().putRefMOdel(refNodeName,
								model);

					}
					refBatchMatch.addMatchData(item, superVO, value, model);
				} else {
					// �ǲ���ƥ�䣬�߼��ع�����
					billObject = new DefaultConstEnum(value, value.toString());
					superVO.setAttributeValue(item.getKey()
							+ IBillDataConst.ID_SUFFIX, value.toString());
				}

				// long begin1 = System.currentTimeMillis();
				// Logger.debug("������:"+item.getKey()+" ����ƥ�俪ʼ");
				// model.matchPkData(value.toString());
				// billObject = new DefaultConstEnum(value, model
				// .getRefNameValue());
				// superVO.setAttributeValue(item.getKey()+
				// IBillDataConst.ID_SUFFIX, value.toString());

				// long end = System.currentTimeMillis();
				// Logger.debug("������:"+item.getKey()+" ����ƥ�������������"+(end-begin1)+"ms");

				break;

			case IBillItem.USERDEF:
				
				if (item.getMetaDataProperty() == null
				&& item.getRefType() != null) {

			    // long begin = System.currentTimeMillis();
			    String refNodeName = item.getRefType().split(",")[0];
			
			    AbstractRefModel model = BillAccessUtil.getInstance()
					.getRefModel(refNodeName);
			    if (model == null) {

				model = RefPubUtil.getRefModel(refNodeName);
				BillAccessUtil.getInstance().putRefMOdel(refNodeName,
						model);

			    }
			     refBatchMatch.addMatchData(item, superVO, value, model);
		     }


				break;
			//�����ı��������Ѷ���ת��String�� ���ص�ǰ���ֵ�ֵ�������ǰ����Ϊ�գ�����Ĭ�����ֵ�ֵ��	
			case IBillItem.MULTILANGTEXT:
				if (value instanceof MultiLangText){
					billObject = value.toString();
					if (billObject==null){
						billObject = ((MultiLangText)value).getText();
					}
				}
				break;
			
		    case IBillItem.BOOLEAN:
			     if (value instanceof UFBoolean){
				  billObject = value.toString();
				
			    }
			break;
		}

			superVO.setAttributeValue(item.getKey(), billObject);

		}
	}

	// ��ͷ��β������
	private void loadLoadRelation(IBillItemMeta[] items, ISuperVO superVO,
			NCObject ncObject) {

		for (int i = 0; i < items.length; i++) {
//			loadLoadRelation(items[i].getKey(), superVO, ncObject);
			//2016-1-13 ��Ϊ�����������
			loadLoadRelation(items[i], superVO, ncObject);
		}
	}

	private void loadLoadRelation(IBillItemMeta item, ISuperVO superVO,
			NCObject ncObject) {
		
		if (item.getDataType() == IBillItem.UFREF
				&& item.getMetaDataProperty() != null) {

			ArrayList<IConstEnum> relationitem = getMetaDataRelationItems(item);

			if (relationitem != null) {
				// IConstEnum idConstEnum
				// =(IConstEnum)getBillVO().getParentVO().getAttributeValue(itemkey);
				IConstEnum idConstEnum = null;
				String itemkey = item.getKey();
				//wanglio update 20150519  ������Զ���Ԫ���ݣ�ͨ����ʽ��ֵ�����ӵ��ƶ�����ģ�壬ǿ��ת���ᱨ����
				if (superVO.getAttributeValue(itemkey) instanceof String){
					idConstEnum = new DefaultConstEnum(superVO
							.getAttributeValue(itemkey),(String) superVO
							.getAttributeValue(itemkey));
				}else{
					idConstEnum = (IConstEnum) superVO
							.getAttributeValue(itemkey);
				}
				
				String id=null;
				if (idConstEnum!=null){
					id = (String) idConstEnum.getValue();
	
				}
				
				if (id != null) {
					// IConstEnum Value Object[]:,Key:itemkey
					GetMeteDataRelationItemVaule getBillRelationItemValue = new GetMeteDataRelationItemVaule(
							item.getMetaDataProperty().getRefBusinessEntity());
					IConstEnum[] o = getBillRelationItemValue
							.getRelationItemValue(relationitem,
									new String[] { id });
					if (o != null) {
						for (int i = 0; i < o.length; i++) {
							if (o[i].getValue() != null) {
								Object[] v = (Object[]) o[i].getValue();

								// superVO.setAttributeValue(relationitem.get(i)
								// .getName(), v[0]);

								Object oldValue = superVO
										.getAttributeValue(relationitem.get(i)
												.getName());
								if (oldValue != null
										&& oldValue instanceof DefaultConstEnum) {
									Object pk = ((DefaultConstEnum) oldValue)
											.getValue();
//									String name = v[0] == null ? null : v[0]
//											.toString();
//									DefaultConstEnum newValue = new DefaultConstEnum(
//											pk, name);
//									superVO.setAttributeValue(relationitem.get(
//											i).getName(), newValue);
									//modify by fanchj1 2015/11/7
									//�ݴ�����ʾҵ���鿪���������õ�pk��Ϊcode��������pk�����⣻
									//���磺�������뵥�н������ͣ�������ҵ�����er_mtapp_bill�洢��Ϊcodeֵ������pk������ʾ�������ݵ����⣻
									DefaultConstEnum newValue = null;
									if(v[0] == null){
										newValue = (DefaultConstEnum) oldValue;
									}else{
										newValue = new DefaultConstEnum(
												pk, v[0].toString());
									}
									superVO.setAttributeValue(relationitem.get(
											i).getName(), newValue);
								}else if (oldValue != null  //wanglio add 20150519
										&& oldValue instanceof String) {
									Object pk = (String) oldValue;
									String name = v[0] == null ? null : v[0]
											.toString();
									DefaultConstEnum newValue = new DefaultConstEnum(
											pk, name);
									superVO.setAttributeValue(relationitem.get(
											i).getName(), newValue);
								} else {
									superVO.setAttributeValue(relationitem.get(
											i).getName(), v[0]);
								}

							}

						}
					}
				}
			}

		}

	}
	//���淽����ʱ����
	private void loadLoadRelation(String itemkey, ISuperVO superVO,
			NCObject ncObject) {
		//2016-1-13 �޸�
		//���淽���е����⣬�����ͷ������ͬ��BillItem�����ع�������ܻ����
		//NC�������ķ������뵥�����ƶ������ֻ��˴򿪵����ϵ������˺����벿����ʾ���������������ֺ���ĸ��
	    //���뵥�ı�ͷ���嶼�� itemkey��ͬ���ֶΣ������Ϊ�����ֶ�ֻ���ַ��ͣ�������һ���ǲ�ʹ�õģ���
		//��ͷ���ǲ�������
		
		IBillItemMeta item = getBillVO().getbillItemMeta(itemkey);

		if (item.getDataType() == IBillItem.UFREF
				&& item.getMetaDataProperty() != null) {

			ArrayList<IConstEnum> relationitem = getMetaDataRelationItems(item);

			if (relationitem != null) {
				// IConstEnum idConstEnum
				// =(IConstEnum)getBillVO().getParentVO().getAttributeValue(itemkey);
				IConstEnum idConstEnum = (IConstEnum) superVO
						.getAttributeValue(itemkey);
				String id=null;
				if (idConstEnum!=null){
					id = (String) idConstEnum.getValue();
	
				}
				
				if (id != null) {
					// IConstEnum Value Object[]:,Key:itemkey
					GetMeteDataRelationItemVaule getBillRelationItemValue = new GetMeteDataRelationItemVaule(
							item.getMetaDataProperty().getRefBusinessEntity());
					IConstEnum[] o = getBillRelationItemValue
							.getRelationItemValue(relationitem,
									new String[] { id });
					if (o != null) {
						for (int i = 0; i < o.length; i++) {
							if (o[i].getValue() != null) {
								Object[] v = (Object[]) o[i].getValue();

								// superVO.setAttributeValue(relationitem.get(i)
								// .getName(), v[0]);

								Object oldValue = superVO
										.getAttributeValue(relationitem.get(i)
												.getName());
								if (oldValue != null
										&& oldValue instanceof DefaultConstEnum) {
									Object pk = ((DefaultConstEnum) oldValue)
											.getValue();
									String name = v[0] == null ? null : v[0]
											.toString();
									DefaultConstEnum newValue = new DefaultConstEnum(
											pk, name);
									superVO.setAttributeValue(relationitem.get(
											i).getName(), newValue);
								} else {
									superVO.setAttributeValue(relationitem.get(
											i).getName(), v[0]);
								}

							}

						}
					}
				}
			}

		}

	}

	public BillVO getBillVOByMetaData() {

		if (this.billTempletVO == null || this.oData == null) {
			return null;
		}
		long begin = System.currentTimeMillis();
		Logger.debug("ҵ�����ݿ�ʼת��BIllVO");

		IBusinessEntity be = billTempletVO.getHeadVO()
				.getBillMetaDataBusinessEntity();

		BillItemMeta[] itemMetas = getHeadTailItemMetas();
		BillTabVO[] tabvos = getBaseBodyTabVos();

		if (itemMetas != null) {
			NCObject ncobject = null;

			long ojbectBegin = System.currentTimeMillis();
			Logger.debug("�����ͷ��βNCObject��ʼ");

			if (be.getBeanStyle().getStyle() == BeanStyleEnum.AGGVO_HEAD)
				ncobject = DASFacade.newInstanceWithContainedObject(be, oData);
			else if (be.getBeanStyle().getStyle() == BeanStyleEnum.NCVO
					|| be.getBeanStyle().getStyle() == BeanStyleEnum.POJO) {
				if (oData instanceof AggregatedValueObject) {
					oData = ((AggregatedValueObject) oData).getParentVO();
					ncobject = DASFacade.newInstanceWithContainedObject(be,
							oData);
				} else {
					ncobject = DASFacade.newInstanceWithContainedObject(be,
							oData);
				}
			}
			long objectEnd = System.currentTimeMillis();
			Logger.debug("�����ͷ��βNCObject������������" + (objectEnd - ojbectBegin)
					+ "ms");

			ISuperVO parentVO = new BillDataVO();

			getBillVO().setParentVO(parentVO);

			// ���ñ�ͷ����
			dealWithHeadTailVO(itemMetas, ncobject, parentVO);

			// ���ñ�������
			if (tabvos != null) {
				long begin1 = System.currentTimeMillis();
				Logger.debug("���ñ������ݿ�ʼ");
				Logger.debug("���干" + tabvos.length + "��ҳǩ������Ҫ����");
				for (int i = 0; i < tabvos.length; i++) {
					BillTabVO tabVO = tabvos[i];

					NCObject[] ncos = (NCObject[]) ncobject
							.getAttributeValue(tabVO.getMetadatapath());

					if (ncos != null) {

						dealWithChildVOsByTab(tabVO, ncos);
					}

				}

				long end1 = System.currentTimeMillis();
				Logger.debug("���ñ������ݽ���,������" + (end1 - begin1) + "ms");
			}
		} else {
			// ������
			long begin1 = System.currentTimeMillis();
			Logger.debug("���ñ������ݿ�ʼ");
			Logger.debug("���干" + tabvos.length + "��ҳǩ������Ҫ����");
			Object[] vos = null;
			if (oData instanceof AggregatedValueObject)
				vos = ((AggregatedValueObject) oData).getChildrenVO();
			else if (oData.getClass().isArray())
				vos = (Object[]) oData;

			if (vos != null && tabvos != null
					&& tabvos[0].getBillMetaDataBusinessEntity() != null) {

				NCObject[] ncos = new NCObject[vos.length];

				for (int i = 0; i < ncos.length; i++) {
					ncos[i] = DASFacade.newInstanceWithContainedObject(
							tabvos[0].getBillMetaDataBusinessEntity(), vos[i]);
				}

				dealWithChildVOsByTab(tabvos[0], ncos);
			}
			long end1 = System.currentTimeMillis();
			Logger.debug("���ñ������ݽ���,������" + (end1 - begin1) + "ms");
		}
		long end = System.currentTimeMillis();
		Logger.debug("ҵ������ת��BIllVO������������:" + (end - begin) + "ms");
		return getBillVO();

	}

	private void executeFormula(IBillItemMeta[] itemMetas, ISuperVO[] vos) {
		if (vos == null) {
			return;
		}

		FormulaProc formulaProc = new FormulaProc();
		formulaProc.execFormulasWithVO(vos, FormulaUtil
				.getAllLoadFormulars(itemMetas), itemMetas);
	}

	private void dealWithHeadTailVO(BillItemMeta[] itemMetas,
			NCObject ncobject, ISuperVO parentVO) {

		long begin = System.currentTimeMillis();
		Logger.debug("���ñ�ͷ��β���ݿ�ʼ");

		Logger.debug("����ͷ��β���ݸ�ֵ����ƥ�俪ʼ");
		refBatchMatch.clear();
		loadLoadValue(itemMetas, parentVO, ncobject);
		refBatchMatch.executeBatch();
		long end1 = System.currentTimeMillis();
		Logger.debug("����ͷ��β���ݸ�ֵ����ƥ�����,������" + (end1 - begin) + "ms");

		Logger.debug("��ͷ��β���ݼ��ع����ʼ");
		// ���ر�ͷ��β������
		loadLoadRelation(itemMetas, getBillVO().getParentVO(), ncobject);
		long end2 = System.currentTimeMillis();
		Logger.debug("��ͷ��β���ݼ��ع��������,������" + (end2 - end1) + "ms");

		Logger.debug("��ͷ��β���ݼ��ع�ʽ��ʼ");
		executeFormula(itemMetas, new ISuperVO[] { parentVO });
		long end3 = System.currentTimeMillis();
		Logger.debug("��ͷ��β���ݼ��ع�ʽ����,������" + (end3 - end2) + "ms");

		Logger.debug("���ñ�ͷ��β��ʼ����,������" + (end3 - begin) + "ms");

	}

	private void dealWithChildVOsByTab(BillTabVO tabVO, NCObject[] ncos) {
		IBillItemMeta[] tabItemMetas = getBillVO().getBodyBillItemMeta(
				tabVO.getTabcode());
		ISuperVO[] childVOs = new BillDataVO[ncos.length];
		getBillVO().setChildrenVO(tabVO.getTabcode(), childVOs);

		long begin = System.currentTimeMillis();
		Logger.debug("���ñ���ҳǩ" + tabVO.getTabname() + "���ݿ�ʼ");
		Logger.debug("���������ݸ�ֵ����ƥ�俪ʼ");
		refBatchMatch.clear();
		for (int j = 0; j < ncos.length; j++) {
			childVOs[j] = new BillDataVO();
			loadLoadValue(tabItemMetas, childVOs[j], ncos[j]);

		}
		refBatchMatch.executeBatch();

		long end1 = System.currentTimeMillis();
		Logger.debug("���������ݸ�ֵ����ƥ�����,������" + (end1 - begin) + "ms");

		Logger.debug("�������ݼ��ع����ʼ");
		loadLoadRelationItemValues(tabItemMetas, childVOs, ncos);
		long end2 = System.currentTimeMillis();
		Logger.debug("�������ݼ��ع��������,������" + (end2 - end1) + "ms");

		Logger.debug("�������ݼ��ع�ʽ��ʼ");
		executeFormula(tabItemMetas, childVOs);

		long end3 = System.currentTimeMillis();
		Logger.debug("�������ݼ��ع�ʽ����,������" + (end3 - end2) + "ms");

		Logger.debug("���ñ���ҳǩ" + tabVO.getTabname() + "���ݽ���,������"+ (end3 - begin) + "ms");
	}

	// �������ع�����,���������
	private void loadLoadRelationItemValues(IBillItemMeta[] tabItemMetas,
			ISuperVO[] superVOs, NCObject[] ncos) {

		BatchGetMeteDataRelationItemVaules gvs = new BatchGetMeteDataRelationItemVaules();

		for (int col = 0; col < tabItemMetas.length; col++) {
			IBillItemMeta item = tabItemMetas[col];

			if (item.getDataType() == IBillItem.UFREF
					&& item.getMetaDataProperty() != null) {

				ArrayList<IConstEnum> relationitem = getMetaDataRelationItems(item);

				if (relationitem != null&&superVOs.length>0) {

					String[] ids = new String[superVOs.length];

					for (int row = 0; row < superVOs.length; row++) {
						Object o = superVOs[row].getAttributeValue(item
								.getKey());

						if (o != null && o instanceof IConstEnum)
							ids[row] = (String) ((IConstEnum) o).getValue();
					}

					gvs.addRelationItem(item, relationitem, ids);

				}
			}
		}

		IConstEnum[] o = gvs.getRelationItemValues();

		if (o == null) {
			return;
		}

		for (int row = 0; row < superVOs.length; row++) {
			if (o != null) {
				for (int i = 0; i < o.length; i++) {
					if (o[i].getValue() != null) {
						Object[] v = (Object[]) o[i].getValue();
						Object oldValue = superVOs[row].getAttributeValue(o[i]
								.getName());
						if (oldValue != null
								&& oldValue instanceof DefaultConstEnum) {
							Object pk = ((DefaultConstEnum) oldValue)
									.getValue();
							String name = v[row] == null ? null : v[row]
									.toString();
							DefaultConstEnum newValue = new DefaultConstEnum(
									pk, name);
							superVOs[row].setAttributeValue(o[i].getName(),
									newValue);
						} else {
							superVOs[row].setAttributeValue(o[i].getName(),
									v[row]);
						}

					}
				}
			}
		}
	}

	// ���طǹ�����
	private void loadLoadValue(IBillItemMeta[] itemMetas, ISuperVO superVO,
			NCObject ncobject) {
		for (int i = 0; i < itemMetas.length; i++) {

			// ��ͷ���⴦�������и����ؼ���
			if (IBillDataConst.IBODYROWCOUNT.equals(itemMetas[i].getKey())) {
				superVO.setAttributeValue(itemMetas[i].getKey(),
						getBodyRowAcount());
				continue;
			}

			if (itemMetas[i].getMetaDataProperty() != null) {
				// ������ʵ������ֱ�Ӹ�ֵ
				if (itemMetas[i].getIDColName() == null)
					setItemValue(itemMetas[i], superVO, ncobject
							.getAttributeValue(itemMetas[i]
									.getMetaDataProperty().getAttribute()));
			} else {
				//modify by fanchj1 2015/11/30
				//����ͨ������ģ�����ӵ��Զ������Ԫ�����ϵ��Զ�����������͵��Զ�����������õ������ͣ�
				//���￼�ǲ�������
				if(itemMetas[i].getDataType() == IBillItem.UFREF){
					if (itemMetas[i].getRefType() != null) {
						String refType = itemMetas[i].getRefType();
						if(refType!=null && !refType.contains(",")){
							break;
						}
						String refNodeName = refType.split(",")[0];
						if(refNodeName.contains(":"))
							refNodeName = refNodeName.split(":")[1];

						AbstractRefModel model = BillAccessUtil.getInstance()
								.getRefModel(refNodeName);
						if (model == null) {

							model = RefPubUtil.getRefModel(refNodeName);
							BillAccessUtil.getInstance().putRefMOdel(refNodeName,
									model);

						}
						refBatchMatch.addMatchData(itemMetas[i], superVO, ncobject
								.getAttributeValue(itemMetas[i].getKey()), model);
					}
				}
				superVO.setAttributeValue(itemMetas[i].getKey(), ncobject
						.getAttributeValue(itemMetas[i].getKey()));
			}
		}
	}

	private BillTempletVO getBillTempletVO() {
		return billTempletVO;
	}

	private ArrayList<IConstEnum> getMetaDataRelationItems(IBillItemMeta item) {

		if (item.getDataType() != IBillItem.UFREF&&item.getDataType() != IBillItem.COMBO)
			return null;

		if (item.getMetaDataProperty() == null)
			return null;

		ArrayList<IConstEnum> ics = new ArrayList<IConstEnum>();

		// ���ITEM��������
		if (item.getRelationItemMeta() != null) {
			for (int i = 0; i < item.getRelationItemMeta().size(); i++) {
				IBillItemMeta ritem = item.getRelationItemMeta().get(i);

				IConstEnum ic = new DefaultConstEnum(ritem.getMetadatapath(),
						ritem.getKey());
				ics.add(ic);
			}
		}
		IConstEnum ic = getItemSelfRelationItem(item);
		if (ic != null) {
			ics.add(ic);
		}
		if (ics.size() == 0)
			ics = null;

		return ics;

	}

	private IConstEnum getItemSelfRelationItem(IBillItemMeta item) {

		String showattname = getRefItemShowAttributeName(item);
		IConstEnum ic = null;
		if (showattname != null) {
			ic = new DefaultConstEnum(showattname, item.getKey());

		}
		return ic;
	}

	private String getRefItemShowAttributeName(IBillItemMeta item) {
		String showattname = item.getMetaDataProperty()
				.getBDNameAttributeName();
		;

		return showattname;
	}

	private BillVO getBillVO() {
		if (billVO == null) {
			billVO = new BillVO(getBillTempletVO());
		}
		return billVO;
	}

	public Map<String, List<Map<String, Object>>> billVO2Map() {
		BillVO billVO = getBillVOByMetaData();
		if (billVO == null) {
			return null;
		}

		Map<String, List<Map<String, Object>>> map = new LinkedHashMap<String, List<Map<String, Object>>>();

		// ������ͷ

		putHeadTailData(billVO, map, IBillDataConst.HEAD);
		// ������β
		putHeadTailData(billVO, map, IBillDataConst.TAIL);

		// ��������
		putBodyData(billVO, map);

		return map;
	}

	private void putHeadTailData(BillVO billVO,
			Map<String, List<Map<String, Object>>> map, int pos) {
		ISuperVO headTailVO = billVO.getParentVO();
		BillTabVO[] tabVOs = billVO.getTabVOPos(pos);
		BillAccessUtil accessUtil = BillAccessUtil.getInstance();
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		for (int i = 0; i < tabVOs.length; i++) {
			if (tabVOs[i].getBasetab() == null) {
				Map<String, Object> tabMap = new LinkedHashMap<String, Object>();
				tabMap.put(IBillDataConst.TABCODE, tabVOs[i].getTabcode());
				tabMap.put(IBillDataConst.TABNAME, tabVOs[i].getTabname());
				tabMap.put(IBillDataConst.TABCONTENT, accessUtil.getTabDataMap(
						billVO, tabVOs[i], headTailVO));
				list.add(tabMap);
			}
		}
		String key = (pos == IBillDataConst.HEAD) ? IBillDataConst._HEAD
				: IBillDataConst._TAIL;
		map.put(key, list);

	}

	private void putBodyData(BillVO billVO,
			Map<String, List<Map<String, Object>>> map) {

		BillTabVO[] tabVOs = billVO.getTabVOPos(IBillDataConst.BODY);

		BillAccessUtil accessUtil = BillAccessUtil.getInstance();
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		for (int i = 0; i < tabVOs.length; i++) {

			Map<String, Object> tabMap = new LinkedHashMap<String, Object>();
			tabMap.put(IBillDataConst.TABCODE, tabVOs[i].getTabcode());
			tabMap.put(IBillDataConst.TABNAME, tabVOs[i].getTabname());
			tabMap.put(IBillDataConst.TABCONTENT, accessUtil.getTabDataMap(
					billVO, tabVOs[i], billVO.getChildrenVO(tabVOs[i]
							.getTabcode())));

			list.add(tabMap);

		}
		map.put(IBillDataConst._BODY, list);
	}
}
