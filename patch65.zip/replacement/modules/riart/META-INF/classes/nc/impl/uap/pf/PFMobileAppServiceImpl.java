package nc.impl.uap.pf;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import nc.bs.dao.BaseDAO;
import nc.bs.framework.common.InvocationInfoProxy;
import nc.bs.framework.common.NCLocator;
import nc.bs.framework.core.util.ObjectCreator;
import nc.bs.logging.Logger;
import nc.bs.ml.NCLangResOnserver;
import nc.bs.pub.filesystem.IQueryFolderTreeNodeService;
import nc.bs.pub.pf.IimageScan;
import nc.bs.pub.pf.PfUtilTools;
import nc.bs.wf.attrment.BillAttrmentUtil;
import nc.bs.wfengine.engine.ActivityInstance;
import nc.itf.uap.IUAPQueryBS;
import nc.itf.uap.pf.IPFChecknoteService;
import nc.itf.uap.pf.IPFMobileAppService;
import nc.itf.uap.pf.IWorkflowAdmin;
import nc.itf.uap.pf.IWorkflowDefine;
import nc.itf.uap.pf.IWorkflowMachine;
import nc.itf.uap.pf.IplatFormEntry;
import nc.jdbc.framework.SQLParameter;
import nc.jdbc.framework.processor.ArrayListProcessor;
import nc.jdbc.framework.processor.ArrayProcessor;
import nc.jdbc.framework.processor.BeanProcessor;
import nc.message.Attachment;
import nc.message.ByteArrayAttachment;
import nc.message.vo.AttachmentVO;
import nc.ui.pf.checknote.PfChecknoteEnum;
import nc.ui.pf.multilang.PfMultiLangUtil;
import nc.vo.bd.psn.PsndocVO;
import nc.vo.jcom.lang.StringUtil;
import nc.vo.ml.MultiLangUtil;
import nc.vo.pf.mobileapp.ICategory;
import nc.vo.pf.mobileapp.ITaskType;
import nc.vo.pf.mobileapp.MobileAppUtil;
import nc.vo.pf.mobileapp.MobileImageScanConfig;
import nc.vo.pf.mobileapp.MobileImageScanHandler;
import nc.vo.pf.mobileapp.TaskMetaData;
import nc.vo.pf.mobileapp.TaskTypeFactory;
import nc.vo.pf.mobileapp.query.ActionCodeConst;
import nc.vo.pf.mobileapp.query.ApproveDetailQuery;
import nc.vo.pf.mobileapp.query.PaginationQueryFacade;
import nc.vo.pf.mobileapp.query.TaskQuery;
import nc.vo.pf.mobileapp.query.UserMatcher;
import nc.vo.pf.mobileapp.query.UserQuery;
import nc.vo.pf.pub.util.ArrayUtil;
import nc.vo.pub.AggregatedValueObject;
import nc.vo.pub.BusinessException;
import nc.vo.pub.checknote.PfChecknoteVO;
import nc.vo.pub.filesystem.NCFileNode;
import nc.vo.pub.filesystem.NCFileVO;
import nc.vo.pub.lang.UFBoolean;
import nc.vo.pub.lang.UFDouble;
import nc.vo.pub.pf.AssignableInfo;
import nc.vo.pub.pf.Pfi18nTools;
import nc.vo.pub.pf.workflow.IPFActionName;
import nc.vo.pub.workflownote.WorkflownoteAttVO;
import nc.vo.pub.workflownote.WorkflownoteVO;
import nc.vo.sm.UserVO;
import nc.vo.trade.sqlutil.IInSqlBatchCallBack;
import nc.vo.trade.sqlutil.InSqlBatchCaller;
import nc.vo.uap.pf.OrganizeUnit;
import nc.vo.uap.wfmonitor.ProcessRouteRes;
import nc.vo.wfengine.core.activity.Activity;
import nc.vo.wfengine.core.activity.GenericActivityEx;
import nc.vo.wfengine.core.activity.SubFlow;
import nc.vo.wfengine.core.parser.UfXPDLParser;
import nc.vo.wfengine.core.participant.Participant;
import nc.vo.wfengine.core.workflow.WorkflowProcess;
import nc.vo.wfengine.definition.WorkflowTypeEnum;
import nc.vo.wfengine.pub.WfTaskOrInstanceStatus;
import nc.vo.wfengine.pub.WfTaskType;

import org.apache.commons.codec.binary.Base64;

import uap.pub.fs.client.FileStorageClient;

public class PFMobileAppServiceImpl implements IPFMobileAppService {

	private IUAPQueryBS qry = null;

	private BaseDAO persistentDAO;

	private IUAPQueryBS getQueryService() {
		if (qry == null) {
			qry = NCLocator.getInstance().lookup(IUAPQueryBS.class);
		}
		return qry;
	}

	private BaseDAO getPersistentDAO() {
		if (persistentDAO == null) {
			persistentDAO = new BaseDAO();
		}
		return persistentDAO;
	}

	private IPFChecknoteService checknoteService;

	private IPFChecknoteService getChecknoteService() {
		if (checknoteService == null) {
			checknoteService = NCLocator.getInstance().lookup(
					IPFChecknoteService.class);
		}
		return checknoteService;
	}

	/**
	 * ת��byte����
	 * */
	public static byte[] convert(Object object) {
		if (object == null)
			return null;
		byte[] bytes = null;
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(bos);
			oos.writeObject(object);
			bytes = bos.toByteArray();
			bos.close();
			oos.close();
		} catch (IOException e) {
			Logger.debug(e.getMessage());
		}
		return bytes;
	}
     /**
      * 1.1	���������ѯ״̬
      */
	@Override
	public Map<String, Object> getTaskButtonList(String status)
			throws BusinessException {

		// Ĭ������Ĵ���,Ĭ�ϴ����ķ�ʽ��status��ֵĬ��ΪgetTaskStatusList�ӿڷ��صĵ�һ��״̬��keyֵ
		if (status == null || status.equals("")) {
			status = ITaskType.CATEGORY_RECEIVED;
			;
		}

		ITaskType[] types = TaskTypeFactory.getInstance().get(status);
		if (ArrayUtil.isNull(types)) {
			throw new IllegalArgumentException("Unsupported status: " + status);
		}
		List<Map<String, Object>> list = MobileAppUtil.createArrayList();

		for (ITaskType t : types) {
			Map<String, Object> map = MobileAppUtil.createHashMap();
			map.put("statuscode", t.getCode());
			map.put("statusname", t.getName());

			list.add(map);
		}

		Map<String, Object> resultMap = MobileAppUtil.createHashMap();

		resultMap.put("statuskey", status);
		resultMap.put("statusstructlist", list);

		return resultMap;
	}
     /**
      * 2.1	��ѯ�����б�
      */
	@Override
	public Map<String, Object> getTaskList(String groupid, String userid,
			String date, String statuskey, String statuscode, String condition,
			Integer startline, Integer count) throws BusinessException {
		ITaskType taskType = MobileAppUtil.getTaskType(statuskey, statuscode);
		TaskQuery query = taskType.createNewTaskQuery();

		// ����TaskQuery�Ĳ�ѯ����
		// �Ա�������id��pkSql
		query.setPk_group(groupid);
		query.setCuserid(userid);
		query.setDate(date);
		query.setTaskType(taskType);
		query.setCondition(condition);

		List<Map<String, Object>> list = PaginationQueryFacade.getInstance()
				.query(query, startline, count);

		Map<String, Object> map = MobileAppUtil.createHashMap();
		map.put("taskstructlist", list);

		return map;
	}
    /**
     * 4.1	��ѯ������ϸ
     */
	@Override
	public Map<String, Object> getTaskBill(String groupid, String userid,
			String taskid, String statuskey, String statuscode)
			throws BusinessException {
		ITaskType taskType = MobileAppUtil.getTaskType(statuskey, statuscode);
		TaskQuery query = taskType.createNewTaskQuery();

		// ��ѯ������ϸ
		Object obj = query.queryTaskBill(taskid);

		// ��ѯ������������
		TaskMetaData tmd = query.queryTaskMetaData(taskid);

		String pk_billtype = tmd.getBillType();
		String billTypeName = Pfi18nTools.i18nBilltypeName(pk_billtype);

		Map<String, Object> map = MobileAppUtil.createHashMap();
		map.put("taskbill", obj);
		map.put("billtypename", billTypeName);

		return map;
	}
    /**
     * 1.2	��ѯ�����б�
     */
	@Override
	public Map<String, Object> getTaskAction(String groupid, String taskid,
			String statuskey, String statuscode) throws BusinessException {
		ITaskType taskType = MobileAppUtil.getTaskType(statuskey, statuscode);
		TaskQuery query = taskType.createNewTaskQuery();

		return query.queryTaskActions(taskid);
	}
    /**
     * 5.1	ͬ����������
     */
	@Override
	public Map<String, Object> doAgree(String groupid, String userid,
			String taskid, String note, List<String> cuserids)
			throws BusinessException {
		TaskMetaData tmd = MobileAppUtil.queryTaskMetaData(
				ITaskType.CATEGORY_RECEIVED, ITaskType.RECEIVED_UNHANDLED,
				taskid);
		String actioncode = null;
		int type = tmd.getWorkflow_type();//����		
		if(WorkflowTypeEnum.Approveflow.getIntValue() == type || WorkflowTypeEnum.SubApproveflow.getIntValue() == type || WorkflowTypeEnum.SubWorkApproveflow.getIntValue() == type){
			actioncode = IPFActionName.APPROVE; //����������
		}else if(WorkflowTypeEnum.Workflow.getIntValue() == type || WorkflowTypeEnum.SubWorkflow.getIntValue() == type){
			actioncode = IPFActionName.SIGNAL; //ִ�й�����
		}else{
			actioncode = "���ʹ�������"+tmd.getWorkflow_type();
		}

		String billtype = tmd.getBillType();
		String billid = tmd.getBillId();
		String result = "Y";

		String[] assigned = null;
		if (!ArrayUtil.isNull(cuserids)) {
			assigned = cuserids.toArray(new String[0]);
		}

		try {
			PfUtilTools.approveSilently(billtype, billid, result, note, userid,assigned,actioncode);
		} catch (Exception e) {
			MobileAppUtil.handleException(e);
		}

		return MobileAppUtil.createHashMap();
	}
     /**
      * 5.2	��ͬ����������
      */
	@Override
	public Map<String, Object> doDisAgree(String groupid, String userid,
			String taskid, String note, List<String> cuserids)
			throws BusinessException {
		TaskMetaData tmd = MobileAppUtil.queryTaskMetaData(
				ITaskType.CATEGORY_RECEIVED, ITaskType.RECEIVED_UNHANDLED,
				taskid);
		String actioncode = null;
		int type = tmd.getWorkflow_type();//����		
		if(WorkflowTypeEnum.Approveflow.getIntValue() == type || WorkflowTypeEnum.SubApproveflow.getIntValue() == type || WorkflowTypeEnum.SubWorkApproveflow.getIntValue() == type){
			actioncode = IPFActionName.APPROVE; //����������
		}else if(WorkflowTypeEnum.Workflow.getIntValue() == type || WorkflowTypeEnum.SubWorkflow.getIntValue() == type){
			actioncode = IPFActionName.SIGNAL; //ִ�й�����
		}else{
			actioncode = "���ʹ�������"+tmd.getWorkflow_type();
		}
		String billtype = tmd.getBillType();
		String billid = tmd.getBillId();
		String result = "N";

		String[] assigned = null;
		if (!ArrayUtil.isNull(cuserids)) {
			assigned = cuserids.toArray(new String[0]);
		}

		try {
			
			PfUtilTools.approveSilently(billtype, billid, result, note, userid,assigned,actioncode);
		} catch (Exception e) {
			MobileAppUtil.handleException(e);
		}

		return MobileAppUtil.createHashMap();
	}
	
	public Map<String, Object> doBack(
			String groupid,
			String userid,
			String taskid
	) throws BusinessException {
		TaskMetaData tmd = MobileAppUtil.queryTaskMetaData(ITaskType.CATEGORY_RECEIVED, ITaskType.RECEIVED_HANDLED, taskid);
		String billtype = tmd.getBillType();
		String billid = tmd.getBillId();
		AggregatedValueObject billvo = MobileAppUtil.queryBillEntity(billtype, billid);
		
		//����
		IplatFormEntry srv = NCLocator.getInstance().lookup(IplatFormEntry.class);
		srv.processAction(IPFActionName.UNAPPROVE, billtype, null, billvo, null, null);
		
		return MobileAppUtil.createHashMap();
	}
    /**
     * 5.4	���ض���
     */
	@Override
	public Map<String, Object> doReject(String groupid, String userid,
			String taskid, String note, String nodeid) throws BusinessException {
		TaskMetaData tmd = MobileAppUtil.queryTaskMetaData(
				ITaskType.CATEGORY_RECEIVED, ITaskType.RECEIVED_UNHANDLED,
				taskid);
		String actioncode = null;
		int type = tmd.getWorkflow_type();//����		
		if(WorkflowTypeEnum.Approveflow.getIntValue() == type || WorkflowTypeEnum.SubApproveflow.getIntValue() == type){
			actioncode = IPFActionName.APPROVE; //����������
		}else if(WorkflowTypeEnum.Workflow.getIntValue() == type || WorkflowTypeEnum.SubWorkflow.getIntValue() == type){
			actioncode = IPFActionName.SIGNAL; //ִ�й�����
		}
		String billtype = tmd.getBillType();
		String billid = tmd.getBillId();
		AggregatedValueObject billvo = MobileAppUtil.queryBillEntity(billtype,
				billid);

		IWorkflowMachine srv = NCLocator.getInstance().lookup(
				IWorkflowMachine.class);
		WorkflownoteVO worknoteVO = srv.checkWorkFlow(actioncode,
				tmd.getBillType(), billvo, null);

		// ����һ�����ص�worknoteVO
		worknoteVO.setChecknote(note);
		worknoteVO.setApproveresult("R");
		worknoteVO.getTaskInfo().getTask()
				.setTaskType(WfTaskType.Backward.getIntValue());
		worknoteVO.getTaskInfo().getTask().setSubmit2RjectTache(false);

		if (StringUtil.isEmptyWithTrim(nodeid)) {
			worknoteVO.getTaskInfo().getTask().setBackToFirstActivity(true);
			worknoteVO.getTaskInfo().getTask().setJumpToActivity(null);
		} else {
			worknoteVO.getTaskInfo().getTask().setBackToFirstActivity(false);
			worknoteVO.getTaskInfo().getTask().setJumpToActivity(nodeid);
		}

		// ���÷�����в��ز���
		IplatFormEntry entry = NCLocator.getInstance().lookup(
				IplatFormEntry.class);
		entry.processAction(actioncode, billtype, worknoteVO,
				billvo, null, (HashMap) MobileAppUtil.createHashMap());

		return MobileAppUtil.createHashMap();
	}
    /**
     * 4.3	��ѯ��Ա�б�
     */
	@Override
	public Map<String, Object> getUserList(String groupid, String userid,
			String taskid, int startline, int count, String condition)
			throws BusinessException {

		List<Map<String, Object>> list = null;

		if (StringUtil.isEmptyWithTrim(condition)) {
			UserQuery query = new UserQuery(groupid);
			list = PaginationQueryFacade.getInstance().query(query, startline,
					count);
		} else {
			// TODO: ������IPaginationedQueryʵ��
			UserMatcher matcher = new UserMatcher();
			List<UserVO> matched = matcher.matchAll("pk_group='" + groupid
					+ "'", condition);
			List<UserVO> paginated = MobileAppUtil.subList(matched, startline,
					count);

			list = MobileAppUtil.createArrayList();

			for (UserVO uvo : paginated) {
				Map<String, Object> map = MobileAppUtil.createHashMap();

				map.put("id", uvo.getCuserid());
				map.put("code", uvo.getUser_code());
				map.put("name", PfMultiLangUtil.getSuperVONameOfCurrentLang(
						uvo, "user_name"));

				list.add(map);
			}
		}

		Map<String, Object> result = MobileAppUtil.createHashMap();
		result.put("psnstructlist", list);

		return result;
	}

	@Override
	public Map<String, Object> doAddApprover(String groupid, String userid,
			String taskid, String note, List<String> userids)
			throws BusinessException {
		if (ArrayUtil.isNull(userids)) {
			throw new IllegalArgumentException("userids is null or empty");
		}
		BaseDAO dao = new BaseDAO();
		IWorkflowAdmin srv = NCLocator.getInstance().lookup(
				IWorkflowAdmin.class);

		WorkflownoteVO worknote = (WorkflownoteVO) dao.retrieveByPK(
				WorkflownoteVO.class, taskid);
		worknote.setExtApprovers(userids);
		worknote.setChecknote(note);

		srv.addApprover(worknote);

		return MobileAppUtil.createHashMap();
	}
    /**
     * 5.5	���ɶ���
     */
	@Override
	public Map<String, Object> doReassign(String groupid, String userid,
			String taskid, String note, String targetUserId)
			throws BusinessException {
		TaskMetaData tmd = MobileAppUtil.queryTaskMetaData(
				ITaskType.CATEGORY_RECEIVED, ITaskType.RECEIVED_UNHANDLED,
				taskid);

		IWorkflowAdmin srv = NCLocator.getInstance().lookup(
				IWorkflowAdmin.class);
		srv.appointWorkitem(tmd.getBillId(), taskid, userid, targetUserId);

		return MobileAppUtil.createHashMap();
	}

	@Override
	public Map<String, Object> getRejectNodeList(String groupid, String userid,
			String taskid, int startline, int count, String condition)
			throws BusinessException {
		// TODO: ���Ż�
		// 1. �����Ż�
		// 2. Ҫȡ���յ��û�?
		TaskMetaData tmd = MobileAppUtil.queryTaskMetaData(
				ITaskType.CATEGORY_RECEIVED, ITaskType.RECEIVED_UNHANDLED,
				taskid);
		WorkflownoteVO worknoteVO = MobileAppUtil.checkWorkflow(taskid);

		IWorkflowDefine srv = NCLocator.getInstance().lookup(
				IWorkflowDefine.class);

		// �����������������в��ܲ��ص���������Ļ��ڣ�ֻ�ܲ��ص��������ϵ������̹ؽ�
		// ����1: ����ǹ������������̣���ôֻ��ʾ���������ʵ�������л���
		// ����2������������������̣���ô��ʾ�������������Ѱ죨���������ڵ㣬���������̽ڵ㣩�ͱ��������������Ѱ�
		// ����3����������������̣���ô��ʾ�����Ѱ��������̽ڵ㣨��������ڵ㣩

		List<ProcessRouteRes> prrList = new ArrayList<ProcessRouteRes>();

		String billid = tmd.getBillId();
		String billtype = tmd.getBillType();
        
		int workflowType = worknoteVO.getWorkflow_type();
		if (workflowType == WorkflowTypeEnum.SubWorkApproveflow.getIntValue()) {
			String pk_wf_instance = worknoteVO.getTaskInfo().getTask().getWfProcessInstancePK();
			ProcessRouteRes prr = srv.queryProcessRoute(billid,billtype, pk_wf_instance, workflowType);
			prrList.add(prr);
		} else if (workflowType == WorkflowTypeEnum.SubApproveflow.getIntValue()) {
			ProcessRouteRes prr = srv.queryProcessRoute(billid,billtype, null,WorkflowTypeEnum.Approveflow.getIntValue());
			prrList.add(prr);
			String pk_wf_instance = worknoteVO.getTaskInfo().getTask().getWfProcessInstancePK();
			prr = srv.queryProcessRoute(billid, billtype, pk_wf_instance,workflowType);
			prrList.add(prr);
		} else if (workflowType == WorkflowTypeEnum.Workflow.getIntValue()) {
			ProcessRouteRes prr = srv.queryProcessRoute(billid, billtype,null, WorkflowTypeEnum.Workflow.getIntValue());
			prrList.add(prr);			
		}else if (workflowType == WorkflowTypeEnum.SubWorkflow.getIntValue()) {
			ProcessRouteRes prr = srv.queryProcessRoute(billid, billtype,null, WorkflowTypeEnum.Workflow.getIntValue());
			prrList.add(prr);
		}else {
			ProcessRouteRes prr = srv.queryProcessRoute(tmd.getBillId(),tmd.getBillType(), null,WorkflowTypeEnum.Approveflow.getIntValue());
			prrList.add(prr);
		}

		try {
			List<Map<String, Object>> resultList = getCheckedActivities(
					prrList.toArray(new ProcessRouteRes[0]), condition);

			// pagination
			resultList = MobileAppUtil.subList(resultList, startline, count);

			Map<String, Object> map = MobileAppUtil.createHashMap();
			map.put("psnstructlist", resultList);

			return map;
		} catch (Exception e) {
			MobileAppUtil.handleException(e);
			return null;
		}
	}
		
		/**
		 * �Ƿ����������̻��߹���������������
		 * 
		 * @return
		 */
		private boolean isSubWorkFlow(WorkflownoteVO workFlownote) {
			if (workFlownote.getWorkflow_type() == WorkflowTypeEnum.SubWorkflow
					.getIntValue()) {
				return true;
			} else if (workFlownote.getWorkflow_type() == WorkflowTypeEnum.SubWorkApproveflow
					.getIntValue()) {
				return true;
			} else {
				return false;
			}
		}

	private List<Map<String, Object>> getCheckedActivities(
			ProcessRouteRes[] prs, String matchString) throws Exception {
		List<Map<String, Object>> resultList = MobileAppUtil.createArrayList();

		if (prs != null) {
			for (ProcessRouteRes p : prs) {
				ActivityInstance[] ais = p.getActivityInstance();
				WorkflowProcess wp = null;
				if (p.getXpdlString() != null) {
					String def_xpdl = p.getXpdlString().toString();
					wp = UfXPDLParser.getInstance().parseProcess(def_xpdl);
				}

				if (wp != null) {
					for (ActivityInstance inst : ais) {
						if (inst.getStatus() != WfTaskOrInstanceStatus.Finished
								.getIntValue()) {
							continue;
						}

						Activity act = wp
								.findActivityByID(inst.getActivityID());

						if (act instanceof GenericActivityEx) {
							GenericActivityEx gae = (GenericActivityEx) act;
							Participant parti = wp.findParticipantByID(gae
									.getPerformer());

							String name = parti.getName();

							// ��������ƥ��
							if (!StringUtil.isEmptyWithTrim(matchString)
									&& !name.contains(matchString)) {
								continue;
							}
							
							// Aug 27th, 2018 -- PENGL
							// �޸���������ص�������ʾ���Զ��塱�����á�����ơ�������
							if("�Զ���".equals(name)){
								String actName = act.toString();
								int position = actName.indexOf("<");
								if(position > -1)
									name = actName.substring(0, position);
								else
									name = actName;
							}

							String id = gae.getId();
							String code = gae.getPerformer();

							Map<String, Object> actEntry = MobileAppUtil
									.createHashMap();

							actEntry.put("id", id);
							// yanke1 ��ma�������ֹ� ����activity��û��code�ģ����ﴫ�վͿ���
							actEntry.put("code", "");
							// actEntry.put("code", code);
							actEntry.put("name", name);

							resultList.add(actEntry);
						} else if (act.getImplementation() instanceof SubFlow) {
							String id = act.getId();
							String code = act.getId();
							String name = act.getName();

							Map<String, Object> actEntry = MobileAppUtil
									.createHashMap();

							actEntry.put("id", id);
							// actEntry.put("code", code);
							actEntry.put("code", "");
							actEntry.put("name", name);

							resultList.add(actEntry);
						}
					}
				}

				// yanke1 �����������̵���
				// resultList.addAll(getCheckedActivities(p.getSubProcessRoute(),
				// matchString));
			}
		}
		return resultList;
	}
    /**
     * 4.4	��ѯָ����Ա�б�
     */
	@Override
	public Map<String, Object> getAssignPsnList(String groupid, String userid,
			String taskid, String isagree, int startline, int count,
			String condition) throws BusinessException {
		WorkflownoteVO note = MobileAppUtil.checkWorkflow(taskid);
		Vector<AssignableInfo> assignInfos = note.getTaskInfo()
				.getAssignableInfos();

		List<Map<String, Object>> resultList = MobileAppUtil.createArrayList();
		Map<String, String> useridDispatchIdMap = new HashMap<String, String>();

		if (assignInfos != null && assignInfos.size() > 0) {
			String strCriterion = null;
			for (AssignableInfo ai : assignInfos) {
				strCriterion = ai.getCheckResultCriterion();

				if ((
				// ���������Ϊͨ��
						UFBoolean.valueOf(isagree).booleanValue() && ( // ��
																		// ai������Ϊͨ������
						AssignableInfo.CRITERION_NOTGIVEN.equals(strCriterion) || AssignableInfo.CRITERION_PASS
								.equals(strCriterion)

						)) ||
						// ����
						(
						// �������Ϊδͨ��
						!UFBoolean.valueOf(isagree).booleanValue() && ( // ��
																		// ai����Ϊδͨ������
						AssignableInfo.CRITERION_NOTGIVEN.equals(strCriterion) || AssignableInfo.CRITERION_NOPASS
								.equals(strCriterion)))) {
					Vector<OrganizeUnit> vt = ai.getOuUsers();

					if (vt != null && vt.size() > 0) {
						for (OrganizeUnit ou : vt) {
							Map<String, Object> map = MobileAppUtil
									.createHashMap();

							String id = ou.getPk() + "#"
									+ ai.getActivityDefId();

							useridDispatchIdMap.put(ou.getPk(), id);

							map.put("id", id);
							map.put("code", ou.getCode());
							map.put("name", ou.getName());

							resultList.add(map);
						}
					}
				}
			}
		}

		if (!StringUtil.isEmptyWithTrim(condition)) {
			// ģ����ѯ
			Map<Object, Map<String, Object>> converted = MobileAppUtil
					.convertToMap(resultList, "id");
			UserMatcher matcher = new UserMatcher();

			Set<String> cuseridSet = new HashSet<String>();

			for (Iterator<Object> it = converted.keySet().iterator(); it
					.hasNext();) {
				String id = (String) it.next();
				id = id.substring(0, id.indexOf("#"));

				cuseridSet.add(id);
			}

			List<UserVO> matched = matcher.matchWithin(
					cuseridSet.toArray(new String[0]), condition);

			resultList = MobileAppUtil.createArrayList();

			for (UserVO uvo : matched) {
				Map<String, Object> map = MobileAppUtil.createHashMap();

				map.put("id", useridDispatchIdMap.get(uvo.getCuserid()));
				map.put("code", uvo.getUser_code());
				map.put("name", PfMultiLangUtil.getSuperVONameOfCurrentLang(
						uvo, "user_name"));

				resultList.add(map);
			}
		}

		if (resultList != null && resultList.size() > 0) {
			try {
				Map<String, Object>[] array = resultList.toArray(new Map[0]);

				Arrays.sort(array, new Comparator() {

					@Override
					public int compare(Object o1, Object o2) {
						if (o1 instanceof Map && o2 instanceof Map) {
							Object name1 = ((Map) o1).get("name");
							Object name2 = ((Map) o2).get("name");

							if (name1 instanceof String
									&& name2 instanceof String) {
								return ((String) name1)
										.compareToIgnoreCase((String) name2);
							}
						}

						return 0;
					}

				});

				List<Map<String, Object>> tempList = MobileAppUtil
						.createArrayList();

				for (Map<String, Object> row : array) {
					tempList.add(row);
				}

				resultList = tempList;
			} catch (Exception e) {
				Logger.error(e.getMessage(), e);
			}
		}

		resultList = MobileAppUtil.subList(resultList, startline, count);

		Map<String, Object> resultMap = MobileAppUtil.createHashMap();
		resultMap.put("psnstructlist", resultList);

		return resultMap;
	}
     /**
      * 2.2	��ѯ������ʷ
      */
	@Override
	public Map<String, Object> getApprovedDetail(String groupid, String userid,
			String taskid, String statuskey, String statuscode, int startline,
			int count) throws BusinessException {
		TaskMetaData tmd = MobileAppUtil.queryTaskMetaData(statuskey,
				statuscode, taskid);

		ApproveDetailQuery query = new ApproveDetailQuery(tmd);
		List<Map<String, Object>> detailList = PaginationQueryFacade
				.getInstance().query(query, startline, count);

		StringBuffer sb = new StringBuffer();

		String suffix = MultiLangUtil.getCurrentLangSeqSuffix();

		sb.append("select ");
		sb.append("u_t.user_name, ");
		sb.append("u_t.user_name");
		sb.append(suffix);
		sb.append(", ");
		sb.append("i_t.billmaker, i_t.startts from pub_wf_instance i_t left join sm_user u_t on i_t.billmaker=u_t.cuserid  where i_t.billtype=? and i_t.billversionpk=? and i_t.workflow_type=?");

		SQLParameter param = new SQLParameter();
		param.addParam(tmd.getBillType());
		param.addParam(tmd.getBillId());
		// �Ƿ��ǹ������������̣�
		param.addParam(tmd.getWorkflow_type());

		BaseDAO dao = new BaseDAO();
		Object[] summaries = (Object[]) dao.executeQuery(sb.toString(), param,
				new ArrayProcessor());

		Map<String, Object> resultMap = MobileAppUtil.createHashMap();

		if (summaries != null) {
			String billmakerName = summaries[0] == null ? null : String
					.valueOf(summaries[0]);
			String billmakerNameMl = summaries[1] == null ? null : String
					.valueOf(summaries[1]);
			String billmaker = summaries[2] == null ? null : String
					.valueOf(summaries[2]);
			String startts = summaries[3] == null ? null : String
					.valueOf(summaries[3]);

			if (!StringUtil.isEmptyWithTrim(billmakerNameMl)) {
				resultMap.put("makername", billmakerNameMl);
			} else {
				resultMap.put("makername", billmakerName);
			}
			resultMap.put("psnid", billmaker);
			resultMap.put("submitdate", startts);
			resultMap.put("billname", tmd.getBillNo());
			resultMap.put("billtypename",
					Pfi18nTools.i18nBilltypeName(tmd.getBillType()));
		}

		resultMap.put("approvehistorylinelist",
				detailList.get(0).get("approvehistorylinelist"));
		resultMap.put("flowhistory", detailList.get(0).get("flowhistory"));

		return resultMap;
	}
    /**
     * 4.5	��ѯ��Ա��ϵ��Ϣ
     */
	@Override
	public Map<String, Object> getPsnDetail(String groupid, String userid,
			String psnid) throws BusinessException {
		BaseDAO dao = new BaseDAO();

		String sql = "select bd_psndoc_t.* from bd_psndoc bd_psndoc_t join sm_user sm_user_t on bd_psndoc_t.pk_psndoc=sm_user_t.pk_base_doc where sm_user_t.cuserid=?";

		SQLParameter param = new SQLParameter();
		param.addParam(psnid);

		PsndocVO doc = (PsndocVO) dao.executeQuery(sql, param,
				new BeanProcessor(PsndocVO.class));

		if (doc == null) {
			throw new BusinessException(NCLangResOnserver.getInstance()
					.getStrByID("mobileapp", "PFMobileAppServiceImpl-000000",
							null,
							new String[] { Pfi18nTools.getUserName(psnid) })/*
																			 * �޷��ҵ��û�
																			 * :
																			 * {
																			 * 0
																			 * }
																			 * ����Ա����
																			 */);
		}

		Map<String, Object> result = MobileAppUtil.createHashMap();

		doc.getMobile();

		result.put("pname",
				PfMultiLangUtil.getSuperVONameOfCurrentLang(doc, "name"));
		result.put("pdes", MobileAppUtil.getPsnJobInfo(doc.getPk_psndoc()));

		List<Map<String, Object>> list = MobileAppUtil.createArrayList();

		if (!StringUtil.isEmptyWithTrim(doc.getMobile())) {
			Map<String, Object> entry = new HashMap<String, Object>();

			entry.put("msgtype", "0");
			entry.put(
					"propname",
					NCLangResOnserver.getInstance().getStrByID("mobileapp",
							"PFMobileAppServiceImpl-000001")/* �ֻ� */);
			entry.put("propvalue", doc.getMobile());

			list.add(entry);
		}

		if (!StringUtil.isEmptyWithTrim(doc.getOfficephone())) {
			Map<String, Object> entry = new HashMap<String, Object>();

			entry.put("msgtype", "1");
			entry.put(
					"propname",
					NCLangResOnserver.getInstance().getStrByID("mobileapp",
							"PFMobileAppServiceImpl-000002")/* �칫�绰 */);
			entry.put("propvalue", doc.getOfficephone());

			list.add(entry);
		}

		if (!StringUtil.isEmptyWithTrim(doc.getHomephone())) {
			Map<String, Object> entry = new HashMap<String, Object>();

			entry.put("msgtype", "2");
			entry.put(
					"propname",
					NCLangResOnserver.getInstance().getStrByID("mobileapp",
							"PFMobileAppServiceImpl-000003")/* ��ͥ�绰 */);
			entry.put("propvalue", doc.getHomephone());

			list.add(entry);
		}

		if (!StringUtil.isEmptyWithTrim(doc.getEmail())) {
			Map<String, Object> entry = new HashMap<String, Object>();

			entry.put("msgtype", "3");
			entry.put(
					"propname",
					NCLangResOnserver.getInstance().getStrByID("mobileapp",
							"PFMobileAppServiceImpl-000004")/* �����ʼ� */);
			entry.put("propvalue", doc.getEmail());

			list.add(entry);
		}

		result.put("contactinfolist", list);

		return result;
	}
	  /**
     * 2.3	��ѯ�����б�
     */
	@Override
	public Map<String, Object> getMessageAttachmentList(String groupid,
			String userid, String taskid, String statuskey, String statuscode)
			throws BusinessException {
		TaskMetaData tmd = MobileAppUtil.queryTaskMetaData(statuskey,
				statuscode, taskid);

		String sql = null;
		SQLParameter param = null;

		// FIXME: Ӧ���ŵ�taskquery��
		if (ITaskType.CATEGORY_SUBMITTED.equals(statuskey)) {
			sql = "select t_t.pk_file, t_t.filename, t_t.filesize from pub_workflownote_att t_t join pub_workflownote w_t on t_t.pk_checkflow=w_t.pk_checkflow where w_t.pk_billtype=? and w_t.billversionpk=?";

			param = new SQLParameter();
			param.addParam(tmd.getBillType());
			param.addParam(tmd.getBillId());
		} else {
			sql = "select t_t.pk_file, t_t.filename, t_t.filesize from pub_workflownote_att t_t join pub_workflownote w_t on t_t.pk_checkflow=w_t.pk_checkflow where w_t.pk_checkflow=?";

			param = new SQLParameter();
			param.addParam(taskid);
		}

		BaseDAO dao = new BaseDAO();
		Collection<Object[]> col = (Collection<Object[]>) dao.executeQuery(sql,
				param, new ArrayListProcessor());

		List<Map<String, Object>> list = MobileAppUtil.createArrayList();

		if (col != null && col.size() > 0) {
			for (Object[] entry : col) {
				Map<String, Object> entryMap = MobileAppUtil.createHashMap();

				String pk_file = MobileAppUtil.getStringFromObjects(entry, 0);
				String filename = MobileAppUtil.getStringFromObjects(entry, 1);
				String filesize = MobileAppUtil.getStringFromObjects(entry, 2);
				entryMap.put("fileid", pk_file);
				entryMap.put("filename", filename);
				// update by wanggangr 2016/02/03
				// �����ƶ�Ӧ��Ҫ���ļ���С��ʾΪKB
//				double kb = new UFDouble(filesize).getDouble() / 1024;
//				String filesize_kb = MobileAppUtil.adjust2Scale(
//						new UFDouble(kb)).toString();
				int filesize_int = 0;
				String filesize_kb = "δ֪��С";
				try{
					filesize_int = new Integer(filesize);
				} catch (NumberFormatException e) {
					filesize_int = -1;
				}
				if(filesize_int > 0){
					filesize_kb = getFileSize(new Integer(filesize).intValue());
				}
				// update by wanggangr 2016/02/03 end
				entryMap.put("filesize", filesize_kb);
				// entryMap.put("filetype", "");
				entryMap.put("downflag", "1");

				list.add(entryMap);
			}
		}
		
		Integer count = 0;
		if (col != null && col.size() > 0) {
			count = col.size();
		} 

		Map<String, Object> attachment = MobileAppUtil.createHashMap();
		//��ѯ���ݸ�����Ϣ
		Map<String, List<Map<String, Object>>> allbillfile= queryBillAttBatch(new String[]{tmd.getPk_checkflow()});
		if(null != allbillfile.get(tmd.getPk_checkflow())){
			 List<Map<String, Object>> obj = allbillfile.get(tmd.getPk_checkflow());
			 list.addAll(obj);
			 count = count + obj.size();
		}
		List<Map<String, Object>> attachstructlist = new ArrayList<Map<String, Object>>();
		if(null != list && list.size()>0){
			//�����������͵��ݸ����б��ĺϼ�
			attachment.put("attachmentgroupname", "����");
			attachment.put("attachmentgrouplist", list);
			attachstructlist.add(attachment);			
		}
		
		Map<String, Object> map = getCMImageList(taskid, statuskey, statuscode);
		if(null != map){
			//Ӱ��ɨ���ѯ��Ϣ���ؽ��
			Map<String, Object> cmi = MobileAppUtil.createHashMap();
			cmi.put("attachmentgroupname", "Ӱ��");
			cmi.put("attachmentgrouplist", map.get("attachmentgrouplist"));
			attachstructlist.add(cmi);
			count = count + (Integer)map.get("count");
		}
		
		Map<String, Object> attchmentGroup = MobileAppUtil.createHashMap();
		attchmentGroup.put("attachstructlist", attachstructlist);
		attchmentGroup.put("count", String.valueOf(count));//�ļ�����
		return attchmentGroup;
	}

	
	/**
	 * ����pk_checkflow  ��ѯpub_workflownote�е���Ϣ��֮��ȡ��ѯ����
	 * ֧������
	* @Title: queryBillAttBatch 
	* @Description: TODO(������һ�仰�����������������) 
	* @param @param msgVOs
	* @param @return
	* @param @throws BusinessException    �趨�ļ� 
	* @return Map<String,List<Map<String,Object>>>    �������� 
	* @throws
	 */
	private Map<String, List<Map<String, Object>>> queryBillAttBatch(String[] pk_checkflows) throws BusinessException {
		ArrayList<String> pks = new ArrayList<String>();
		for (String pk : pk_checkflows) {
			pks.add(pk);
		}
		final Map<String, List<Map<String, Object>>> noteID_billAttr_map = new HashMap<String, List<Map<String, Object>>>();
		InSqlBatchCaller caller = new InSqlBatchCaller(pks);
		try {
			caller.execute(new IInSqlBatchCallBack() {

				private BillAttrmentUtil util = new BillAttrmentUtil();

				@Override
				public Object doWithInSql(String inSql)
						throws BusinessException, SQLException {
					String sql = "select pk_checkflow,billversionpk,pk_billtype from pub_workflownote where pk_checkflow in "
							+ inSql;
					@SuppressWarnings("unchecked")
					List<Object[]> result = (List<Object[]>) new BaseDAO()
							.executeQuery(sql, new ArrayListProcessor());
					for (Object[] objs : result) {
						String pk_workflownote = (String) objs[0];
						String billID = (String) objs[1];
						String pk_billtype = (String) objs[2];
						String rootPath = util.getBillAttrRootPath(pk_billtype,billID);
						noteID_billAttr_map.put(pk_workflownote,getBillAttrVOsByBillID(rootPath));
					}
					return null;
				}
			});
		} catch (SQLException e) {
			Logger.error(e.getMessage(), e);
			throw new BusinessException("��ѯ���ݸ�������" + e.getMessage(), e);
		}

		return noteID_billAttr_map;
	}
	
	/**
	 * ��ѯ���ݸ���
	* @Title: getBillAttrVOsByBillID 
	* @Description: TODO(������һ�仰�����������������) 
	* @param @param rootPath   ������������ַ
	* @param @return
	* @param @throws BusinessException    �趨�ļ� 
	* @return List<Map<String,Object>>    �������� 
	* @throws
	 */
	private List<Map<String, Object>> getBillAttrVOsByBillID(String rootPath)
			throws BusinessException {
		List<Map<String, Object>> billfile = new ArrayList<Map<String, Object>>();
		IQueryFolderTreeNodeService service = NCLocator.getInstance().lookup(
				IQueryFolderTreeNodeService.class);
		NCFileNode node = service.getNCFileNodeTreeAndCreateAsNeed(rootPath,
				InvocationInfoProxy.getInstance().getUserId());
		node = findNode(node, rootPath);
		if (node != null) {
			@SuppressWarnings("unchecked")
			Enumeration<NCFileNode> enumer = node.breadthFirstEnumeration();
			//IGeneralAccessor accessor = GeneralAccessorFactory.getAccessor(IMPUap6Const.MEATDATAID_USER);
			while (enumer.hasMoreElements()) {
				NCFileNode tempNode = (NCFileNode) enumer.nextElement();
				Map<String, NCFileVO> map = tempNode.getFilemap();
				for (String filename : map.keySet()) {
					NCFileVO file = map.get(filename);
					Map<String, Object> entryMap = MobileAppUtil.createHashMap();
					entryMap.put("fileid", file.getPk_doc());
					entryMap.put("filename", file.getName());
					// update by wanggangr 2016/02/04
					// �����ƶ�Ӧ��Ҫ���ļ���С��ʾΪKB
//					double kb = new UFDouble(file.getFileLen()).getDouble() / 1024;
//					String filesize_kb = MobileAppUtil.adjust2Scale(new UFDouble(kb)).toString();
					String filesize_kb = "δ֪��С";
					if(new Long(file.getFileLen()).compareTo((long)Integer.MAX_VALUE) < 1){
						filesize_kb = getFileSize(new Integer(new Long(file.getFileLen()).intValue()).intValue());
					}
					// update by wanggangr 2016/02/04 end
					entryMap.put("filesize", filesize_kb);
					entryMap.put("filetype", file.getFiletype());
					entryMap.put("downflag", "1");
					billfile.add(entryMap);
				}
			}
		}
		return billfile;
	}
	
	/**
	 * �ļ���������ļ����ڵĽڵ�
	* @Title: findNode 
	* @Description: TODO(������һ�仰�����������������) 
	* @param @param node   �ڵ�
	* @param @param path  ·��
	* @param @return    �趨�ļ� 
	* @return NCFileNode    �������� 
	* @throws
	 */
	private NCFileNode findNode(NCFileNode node, String path) {
		if (node == null) {
			return null;
		}
		@SuppressWarnings("unchecked")
		Enumeration<NCFileNode> enumer = node.breadthFirstEnumeration();
		NCFileNode retrNode = null;
		while (enumer.hasMoreElements()) {
			NCFileNode tempNode = (NCFileNode) enumer.nextElement();
			if (tempNode.getFullPath().equals(path)) {
				retrNode = tempNode;
				break;
			}
		}
		return retrNode;
	}
	
	/**
	* �õ�Ӱ��ɨ�踽��
	* @Title: getIimageScan 
	* @Description: TODO(������һ�仰�����������������) 
	* @param @return
	* @param @throws BusinessException    �趨�ļ� 
	* @return ArrayList<Map<String,Object>>    �������� 
	* @throws
	*/
	public Map<String, Object> getCMImageList(String taskid,String statuskey,String statuscode) throws BusinessException{
		MobileImageScanConfig config = MobileImageScanHandler.getMobileImageScanConfig();
		Map<String, Object> map = null;
		if(config!=null){
				String name = config.getImageScan();
				if(null !=name && !"".equals(name)){
					//����ʵ��
					IimageScan image = (IimageScan) ObjectCreator.newInstance(name);
					map = image.getCMImageList(taskid,statuskey,statuscode);//�õ�ɨ�踽����ʵ��
				}
		   }
	  return map;
	}

    /**
     * 4.6	��ѯ����
     */
	@Override
	public Map<String, Object> getMessageAttachment(String groupid,
			String userid, String fileid, String downflag, String startposition)
			throws BusinessException {
		// Ŀǰdownflag���ᴫ1
		// startposition�����ô�

		// INCFileSystem srv =
		// NCLocator.getInstance().lookup(INCFileSystem.class);
		Map<String, Object> map = MobileAppUtil.createHashMap();
		Map<String, Object> image = getCMImage(fileid);
		if(image!= null && image.size()>0){
			map.put("downloaded", image.get("downloaded"));
			return map;
		}
		
		ByteArrayOutputStream output = null;
		try {
			output = new ByteArrayOutputStream();
			FileStorageClient.getInstance().downloadByFilePath(fileid, output);
			// srv.doDownload(fileid, output);
		} catch (Exception e) {
			Logger.error(e.getMessage(), e);
		} finally {
			try {
				output.close();
			} catch (Exception e) {
				Logger.error(e.getMessage(), e);
			}
		}

		byte[] downloaded = output.toByteArray();


		map.put("downloaded", downloaded);

		return map;
	}
	
	/**
	 * �õ�Ӱ��ɨ�踽��
	* @Title: getIimageScan 
	* @Description: TODO(������һ�仰�����������������) 
	* @param @return
	* @param @throws BusinessException    �趨�ļ� 
	* @return ArrayList<Map<String,Object>>    �������� 
	* @throws
	* 
	 */
	public  Map<String, Object> getCMImage(String fileid) throws BusinessException{
		MobileImageScanConfig config = MobileImageScanHandler.getMobileImageScanConfig();
		Map<String, Object>  map =  null;
		if(config!=null){
			String name = config.getImageScan();
			if(null !=name && !"".equals(name)){				
					//����ʵ��
					IimageScan image = (IimageScan) ObjectCreator.newInstance(name);
					map = image.getCMImage(fileid);//�õ�ɨ�踽����ʵ��
			}
		}
		return map;
	}

	@Override
	public Map<String, Object> getConditionDescription(String groupid,
			String userid) throws BusinessException {

		String[] supportedFields = new UserMatcher().getSupportedMatchField();

		StringBuffer sb = new StringBuffer();

		for (String f : supportedFields) {
			sb.append("/");
			sb.append(f);
		}

		String resultValue = null;
		if (sb.length() > 0) {
			resultValue = sb.substring(1);
		}

		Map<String, Object> map = new MobileAppUtil().createHashMap();

		map.put("conditiondesc", resultValue);

		return map;
	}
    /**
     * 3.1	��ѯ����״̬�б�
     */
	@Override
	public Map<String, Object> getTaskStatusList(String groupid, String userid)
			throws BusinessException {
		// ���س�ʼ�Ķ���״̬���ҵ������ҵķ���
		ICategory taskType1 = new ICategory() {

			@Override
			public String getCategory() {
				// TODO Auto-generated method stub
				return ITaskType.CATEGORY_RECEIVED;
			}

			@Override
			public String getName() {
				// TODO Auto-generated method stub
				return NCLangResOnserver.getInstance().getStrByID("mobileapp",
						"PFMobileAppServiceImpl-000005")/* �ҵ����� */;
			}

		};
		ICategory taskType2 = new ICategory() {

			@Override
			public String getCategory() {
				// TODO Auto-generated method stub
				return ITaskType.CATEGORY_SUBMITTED;
			}

			@Override
			public String getName() {
				// TODO Auto-generated method stub
				return NCLangResOnserver.getInstance().getStrByID("mobileapp",
						"PFMobileAppServiceImpl-000006")/* �ҵķ��� */;
			}
		};

		Map<String, Object> resultMap = MobileAppUtil.createHashMap();
		List<Map<String, Object>> list = MobileAppUtil.createArrayList();

		// �ҵ�����
		Map<String, Object> entryMap1 = MobileAppUtil.createHashMap();
		entryMap1.put("id", taskType1.getCategory());
		entryMap1.put("name", taskType1.getName());
		list.add(entryMap1);

		// �ҵķ���
		Map<String, Object> entryMap2 = MobileAppUtil.createHashMap();
		entryMap2.put("id", taskType2.getCategory());
		entryMap2.put("name", taskType2.getName());
		list.add(entryMap2);

		resultMap.put("list", list);
		return resultMap;
	}
    /**
     * 3.8	��ȡ������������Ĭ��ֵ
     */
	@Override
	public Map<String, Object> getDefaultValueOfAction(String groupid,
			String userid, String taskid, String statuskey, String statuscode,
			String actioncode) throws BusinessException {
		ITaskType taskType = MobileAppUtil.getTaskType(statuskey, statuscode);
		TaskQuery query = taskType.createNewTaskQuery();
		Map<String, Object> result = query.queryTaskActionDefaultValue(taskid,
				actioncode);
		// �����û��Զ���������
		PfChecknoteVO[] noteVOs = null;
		if (ActionCodeConst.DOAGREE.equals(actioncode)) {
			noteVOs = getChecknoteService().queryCheckNoteByUserpk(userid,
					PfChecknoteEnum.PASS.toInt());
		} else if (ActionCodeConst.DODISAGREE.equals(actioncode)) {
			noteVOs = getChecknoteService().queryCheckNoteByUserpk(userid,
					PfChecknoteEnum.NOPASS.toInt());
		}
		if (noteVOs != null && noteVOs.length > 0) {
			result.put("opinion", noteVOs[0].getNote());
		}

		return result;
	}
    /**
     * 3.12	�����ύ
     */
	@Override
	public Map<String, Object> doAction(String groupid, String userid,
			List<Map<String, Object>> list) throws BusinessException {
		for (Map<String, Object> doActionVO : list) {
			String actioncode = "";
			if (doActionVO.get("actioncode") != null) {
				actioncode = String.valueOf(doActionVO.get("actioncode"));
			}
			dispatchAction(actioncode, groupid, userid, doActionVO);
		}
		return MobileAppUtil.createHashMap();
	}

	/**
	 * ������Ӧ�������룬�ַ�����Ӧ��������
	 * */
	@SuppressWarnings("unchecked")
	private void dispatchAction(String actioncode, String groupid,
			String userid, Map<String, Object> doActionVO)
			throws BusinessException {
		if (doActionVO.get("taskid") == null) {
			throw new BusinessException(NCLangResOnserver.getInstance()
					.getStrByID("mobileapp",
							"PFMobileAppServiceFacadeImpl-000020")/* taskidΪ�� */);
		}
		String taskid = String.valueOf(doActionVO.get("taskid"));
		if (StringUtil.isEmpty(taskid)) {
			throw new BusinessException(NCLangResOnserver.getInstance()
					.getStrByID("mobileapp",
							"PFMobileAppServiceFacadeImpl-000020")/* taskidΪ�� */);
		}

		String note = "";
		if (doActionVO.get("note") != null) {
			note = String.valueOf(doActionVO.get("note"));
		}
		List<String> cuserids = null;
		if (doActionVO.get("userids") == null) {
			
			// Aug 30th, 2018 -- PENGL
			// �޸���ָ�ɵ��û� δ����ȡ���� cuserids == null
			cuserids = (List<String>)doActionVO.get("userids");
		}
		// ת������
		if (ActionCodeConst.DOAGREE.equals(actioncode)) {
			doAgree(groupid, userid, taskid, note, cuserids);
		} else if (ActionCodeConst.DODISAGREE.equals(actioncode)) {
			doDisAgree(groupid, userid, taskid, note, cuserids);
		} else if (ActionCodeConst.DOREJECT.equals(actioncode)) {
			if (doActionVO.get("rejectmarks") == null) {
				throw new BusinessException(NCLangResOnserver.getInstance()
						.getStrByID("mobileapp",
								"PFMobileAppServiceFacadeImpl-000021")/* ���صĻ��ʶΪ�� */);
			}
			List<String> rejectmarks = (List<String>) doActionVO
					.get("rejectmarks");
			if (rejectmarks.size() == 0) {
				throw new BusinessException(NCLangResOnserver.getInstance()
						.getStrByID("mobileapp",
								"PFMobileAppServiceFacadeImpl-000021")/* ���صĻ��ʶΪ�� */);
			}
			if (rejectmarks.size() > 1) {
				throw new BusinessException(NCLangResOnserver.getInstance()
						.getStrByID("mobileapp",
								"PFMobileAppServiceFacadeImpl-000022")/* ���صĻ��ʶ��������1 */);
			}
			doReject(groupid, userid, taskid, note, rejectmarks.get(0));
		} else if (ActionCodeConst.DOREASSIGN.equals(actioncode)) {
			List<String> userids = null;
			if (doActionVO.get("userids") != null) {
				userids = (List<String>) doActionVO.get("userids");
			}
			if (userids == null) {
				throw new BusinessException(NCLangResOnserver.getInstance()
						.getStrByID("mobileapp",
								"PFMobileAppServiceFacadeImpl-000023")/* ָ�ɵ��û�IDΪ�� */);
			}
			if (userids.size() > 1) {
				throw new BusinessException(NCLangResOnserver.getInstance()
						.getStrByID("mobileapp",
								"PFMobileAppServiceFacadeImpl-000024")/* ָ�ɵ��û�ID��������1 */);
			}
			doReassign(groupid, userid, taskid, note, userids.get(0));
		} else if (ActionCodeConst.DOADDAPPROVE.equals(actioncode)) {
			List<String> bsignalusers = null;
			if (doActionVO.get("bsignalusers") != null)
				bsignalusers = (List<String>) doActionVO.get("bsignalusers");
			if (bsignalusers == null) {
				throw new BusinessException(NCLangResOnserver.getInstance()
						.getStrByID("mobileapp",
								"PFMobileAppServiceFacadeImpl-000025")/* ��ǩ���û�IDΪ�� */);
			}

			doAddApprover(groupid, userid, taskid, note, bsignalusers);
		} else
			return;
	}
   /**
    * 3.13	�ϴ��ļ�
    */
	@Override
	public Map<String, Object> uploadFile(String groupid, String userid,
			String taskid, String actioncode, List<Map<String, Object>> filelist)
			throws BusinessException {
		try {
			WorkflownoteVO note = (WorkflownoteVO) getQueryService()
					.retrieveByPK(WorkflownoteVO.class, taskid);
			if (note == null) {
				throw new BusinessException("workflownote is null");
			}
			// ��ȡpk_checkflow��pk_wf_task
			String pk_checkflow_att = note.getPk_checkflow();
			String pk_wf_task = note.getPk_wf_task();
			List<WorkflownoteAttVO> noteAttVOs = new ArrayList<WorkflownoteAttVO>();
			for (Map<String, Object> file : filelist) {
				// base64����
				byte[] data = String.valueOf(file.get("content")).getBytes();
				// base64����
				byte[] byteArray = new Base64().decode(data);
				// ��ȡ��Ϣ����attachment
				Attachment attach = new ByteArrayAttachment(String.valueOf(file
						.get("name")), byteArray);
				// ��ȡattachmentVO
				AttachmentVO attachVO = attach.uploadToFileServer();
				String pk_file = attachVO.getPk_file();

				WorkflownoteAttVO noteAttVO = new WorkflownoteAttVO();
				noteAttVO.setPk_file(pk_file);
				noteAttVO.setPk_wf_task(pk_wf_task);
				// noteAttVO.setPk_checkflow_att(pk_checkflow_att);
				noteAttVO.setPk_checkflow(pk_checkflow_att);
				noteAttVO.setFilename(attachVO.getFilename());
				noteAttVO.setFilesize(attachVO.getFilesize());
				noteAttVOs.add(noteAttVO);
			}

			// ������Ϣ���ݿ�־û�,�빤�������
			getPersistentDAO().insertVOList(noteAttVOs);

		} catch (Exception ex) {
			throw new BusinessException(ex.getMessage());
		}
		return MobileAppUtil.createHashMap();
	}
     /**
      * ��������
      * ��ҪΪ��֧�����������ĽǱ�
      */
	@Override
	public Map<String, Object> getPushNumber(String groupid,
			List<String> usridsList, String type) throws BusinessException {
		// TODO Auto-generated method stub
		List<Map<String, String>> list = MobileAppUtil.getWorkNumByUserIds(
				groupid, usridsList, type);
		Map<String, Object> result = MobileAppUtil.createHashMap();
		result.put("list", list);
		return result;
	}

	@Override
	public Map<String, Object> getTaskBillContent(String groupid,
			String userid, String taskid, String statuskey, String statuscode)
			throws BusinessException {
		// TODO Auto-generated method stub
		ITaskType taskType = MobileAppUtil.getTaskType(statuskey, statuscode);
		TaskQuery query = taskType.createNewTaskQuery();
		TaskMetaData tmd = query.queryTaskMetaData(taskid);
		String pk_billtype = tmd.getBillType();
		String billTypeName = Pfi18nTools.i18nBilltypeName(pk_billtype);
		List<Map<String, Object>> mobileTaskBillList = query
				.queryHTMLTaskBill(taskid);
		Map<String, Object> map = MobileAppUtil.createHashMap();
		map.put("htmlcontent", mobileTaskBillList);
		map.put("taskccontenttype", "1");// HTML����
		map.put("title", billTypeName);
		return map;
	}

	@Override
	public synchronized Map<String, Object> getTaskFlowChart(String groupid,
			String userid, String taskid, String statuskey, String statuscode,
			String picid, String width, String height) throws BusinessException {
		// TODO Auto-generated method stub
		ITaskType taskType = MobileAppUtil.getTaskType(statuskey, statuscode);
		TaskQuery query = taskType.createNewTaskQuery();
		// ��ѯ������������
		TaskMetaData tmd = query.queryTaskMetaData(taskid);
		Map<String, Object> map = query.toPNGImagesWithSubFlow(tmd.getBillId(),
				tmd.getBillType(), tmd.getWorkflow_type(), picid);
		return map;
	}

	// add by wanggangr 2016/02/03
	private  String getFileSize(int filesize) {
		if (filesize < 1024)
			return filesize + "B";
		if ((filesize >= 1024) && (filesize < 1048576)) {
			return (filesize / 1024) + "KB";
		}
		return (filesize / 1048576) + "MB";
	}
	// add by wanggangr 2016/02/03 end
}
